#!/usr/bin/env bash
python3 /sdcard/Antigravity/update_skills.py
