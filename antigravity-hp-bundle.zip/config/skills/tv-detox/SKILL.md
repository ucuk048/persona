---
name: tv-detox
description: Android TV & Google TV debloater, ad-cleaner, and performance booster. Use when user asks to speed up, clean, debloat, or remove bloatware from Android TV or Fire TV over Wi-Fi/ADB.
---

# Android TV Detox

Step-by-step workflow for debloating and removing tracking/ads from Android TV devices.

## Instructions
1. Enable Developer Options & USB/Network Debugging on the TV.
2. Connect to the TV via ADB: .
3. Check installed packages: .
4. Use package candidate list from tv-detox scripts to disable or uninstall safe bloatware packages.
