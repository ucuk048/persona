# Anti-AI-Slop

A free, open-source standard for catching and rewriting the patterns that make text read as if a language model wrote it without a human pass. English and Indonesian, in one standard. Built to run inside the coding agent you already use.

[![antislop-mcp](https://img.shields.io/npm/v/antislop-mcp?label=antislop-mcp)](https://www.npmjs.com/package/antislop-mcp)
[![antislop](https://img.shields.io/npm/v/antislop?label=antislop)](https://www.npmjs.com/package/antislop)
![license](https://img.shields.io/badge/code-MIT-blue)
![content](https://img.shields.io/badge/text-CC--BY--4.0-green)

## What it is

Most anti-slop tools do one of two things: ship an English word-blacklist, or score text and call it "AI-detection". This does neither in isolation. It is a single editorial standard that:

- covers the patterns end to end: symbols, vocabulary, contrast and binary framing, false agency, cadence, sycophancy, the 2026 model-tell panel, and the document-specific tells for prose, slides, marketing copy, and code comments;
- carries a real Indonesian layer, not a translation: the "yang mana" calque, the bureaucratic connector cluster, the "naskah definisi istilah" opener, the formulaic calls-to-action, and the authenticity particles that human Indonesian uses and model Indonesian drops;
- runs as an agent skill and an MCP server, so the check and the rewrite happen where you write;
- treats scoring honestly. It is an editorial style scorer. It is not an authorship detector and not a provenance checker, and it never claims to prove a specific person or model wrote something.

Every rule is both a detector and a rewrite instruction. Finding slop is half the work; the rewrite to natural is the deliverable.

## Install

Pick the surface that fits your tool. All are free and need only Node 18 or newer.

**As a skill or drop-in file (most coding agents):**

```bash
npx antislop init      # drop AGENTS.md into your project
npx antislop cursor    # add the Cursor adapter
npx antislop skill     # add the Claude skill
npx antislop all       # all three
```

**As an MCP server (a rule-based check engine your agent can call):**

```json
{
  "mcpServers": {
    "anti-ai-slop": { "command": "npx", "args": ["-y", "antislop-mcp"] }
  }
}
```

The MCP server gives your agent four tools: `antislop_overview` (the standard), `antislop_check` (run text through the engine and get a rewrite prompt), `antislop_list_categories`, and `antislop_explain`.

## Use

Ask your agent to remove the AI-slop from a draft, or to check whether text reads as machine-written. The engine catches the mechanical tells (symbols, banned vocabulary, contrast and binary framing, false agency, sycophancy, Indonesian calques and marketing cliches) and returns an editorial style score. Your agent adds the judgment the engine cannot: cadence, naturalness, and whether the rewrite still reads like a person wrote it.

## Repository layout

- `protocol/anti-ai-slop.en.md`, `protocol/anti-ai-slop.id.md`: the full standard, English and Indonesian.
- `AGENTS.md`: the compact runnable spine.
- `mcp/`: the MCP server and the rule engine (`antislop.mjs`).
- `cli/`: the `antislop` installer.
- `skills/anti-slop/`, `adapters/cursor/`: the skill and the Cursor adapter.

## A note on detection claims

Three different things are easy to confuse, and this standard is only the first: editorial style scoring (flags stylistic patterns, regardless of authorship), statistical detection (model-signal classifiers, which are biased and evadable and need a running model), and cryptographic provenance marking (C2PA, SynthID, which is blind to non-adopters). Do not read a style score as proof someone used AI. Detectors carry documented bias against non-native English and neurodivergent writers, so a score should never drive an accusation or punitive action.

## License

The code (the `.mjs` files and the build scripts) is MIT; see `LICENSE`. The written standard (the `protocol/` files, the spine, and this documentation) is CC BY 4.0; see `LICENSE-CONTENT`. Use it, adapt it, and ship it, with attribution.

---

## Bahasa Indonesia

Standar terbuka dan gratis untuk mendeteksi dan menulis ulang pola yang membuat teks terasa dibuat model bahasa tanpa sentuhan editor manusia. Dua bahasa, Inggris dan Indonesia, dalam satu standar. Dirancang untuk berjalan di dalam agen koding yang sudah kamu pakai.

Yang membedakannya: lapisan Indonesia yang sungguhan, bukan terjemahan. Standar ini menangkap penanda asli bahasa Indonesia, seperti kalque "yang mana", klaster penghubung birokrasi, pembuka "naskah definisi istilah", ajakan baku ("Yuk simak", "Tunggu apa lagi?"), dan partikel keaslian (nah, sih, dong, kan) yang dipakai penutur manusia tetapi jarang muncul di teks model.

Pasang lewat skill atau MCP yang sama seperti di atas. Standar lengkapnya ada di `protocol/anti-ai-slop.id.md`. Setiap aturan sekaligus detektor dan instruksi penulisan ulang: menemukan slop baru setengah kerja, perbaikannya adalah menulis ulang ke bahasa yang wajar.

Catatan penting: ini penilai gaya editorial, bukan pendeteksi siapa penulisnya, dan bukan pemeriksa asal-usul kriptografis. Skor gaya tidak boleh dipakai untuk menuduh seseorang memakai AI. Pendeteksi punya bias terdokumentasi terhadap penulis non-penutur asli Inggris dan penulis neurodivergen.
