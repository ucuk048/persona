#!/usr/bin/env node
/*
  Anti-slop engine self-test. Asserts the rule engine catches known slop and stays
  quiet on clean text. Run: node scripts/engine-test.mjs  (exit 0 = pass, 1 = fail)
*/
import { lint, ALL_RULES, CATEGORIES } from "../mcp/antislop.mjs";

const fails = [];
const expect = (cond, label) => { if (!cond) fails.push(label); };

// 1. Known English slop must be flagged with the right categories.
const en = lint("This is a robust, cutting-edge solution and it is worth noting that the data tells us it works. It is not just a tool, it is a platform. Would you like me to expand on any of these?");
const enCats = new Set(en.findings.map((f) => f.category));
expect(en.findings.length >= 5, "EN: expected >=5 findings, got " + en.findings.length);
expect(enCats.has("vocabulary"), "EN: missing vocabulary category");
expect(enCats.has("false-agency"), "EN: missing false-agency category");
expect(enCats.has("sycophancy"), "EN: missing sycophancy (turn-closer)");
expect(enCats.has("semantic"), "EN: missing semantic (contrast/binary)");

// 2. Known Indonesian slop must be flagged, including the wedge tells.
const id = lint("Tidak dapat dipungkiri, transformasi digital menjadi salah satu hal krusial. Sistem yang mana dipakai banyak orang. Yuk simak sampai habis!", { lang: "both" });
const idIds = new Set(id.findings.map((f) => f.ruleId));
expect(id.findings.length >= 4, "ID: expected >=4 findings, got " + id.findings.length);
expect(idIds.has("yang-mana"), "ID: missing yang-mana calque");
expect(idIds.has("id-cta"), "ID: missing id-cta marketing tell");
expect([...idIds].some((x) => x.includes("krusial") || x.includes("tidak-dapat")), "ID: missing ID vocabulary tell");

// 3. Clean prose should score high and flag little.
const clean = lint("The build failed last night. The cause was a missing environment variable in the deploy step. I fixed it, added a check that fails the pipeline early when the variable is absent, and re-ran the deploy. It passed.");
expect(clean.score >= 85, "CLEAN: expected score >=85, got " + clean.score);
expect(clean.counts.high === 0, "CLEAN: expected 0 high-severity findings, got " + clean.counts.high);

// 4. Engine shape sanity.
expect(ALL_RULES.length >= 40, "engine: expected >=40 rules, got " + ALL_RULES.length);
expect(CATEGORIES.length >= 8, "engine: expected >=8 categories, got " + CATEGORIES.length);

if (fails.length) {
  console.error("ENGINE TEST FAILED:\n - " + fails.join("\n - "));
  process.exit(1);
}
console.log("engine-test OK (" + ALL_RULES.length + " rules, " + CATEGORIES.length + " categories)");
