#!/usr/bin/env node
/*
  Anti-AI-slop drift-check. Guards the single sources of truth so the distilled
  artifacts cannot quietly diverge. Run: node scripts/check-drift.mjs
  Exit 0 = consistent, exit 1 = drift found (with a list).

  AGENTS.md is hand-distilled from protocol/anti-ai-slop.en.md (not machine
  generated, on purpose). This guards the mechanical invariants: bundled copies
  stay identical to their source, the spine references both protocol files, and
  both bilingual protocol files exist.
*/
import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const problems = [];
const ok = [];
const check = (cond, fail, pass) => { if (cond) { if (pass) ok.push(pass); } else { problems.push(fail); } };
const read = (p) => existsSync(join(root, p)) ? readFileSync(join(root, p), "utf8") : null;

// 1. The AGENTS.md spine and its bundled copies must be identical.
const agents = read("AGENTS.md");
check(agents !== null, "AGENTS.md missing", "AGENTS.md present");
for (const copy of ["mcp/agents.md", "cli/templates/AGENTS.md"]) {
  const c = read(copy);
  if (c === null) continue;
  check(c === agents, copy + " differs from AGENTS.md (regenerate: cp AGENTS.md " + copy + ")", copy + " matches AGENTS.md");
}

// 1b. Other bundled copies must match their source.
for (const [copy, src] of [
  ["cli/templates/anti-slop.mdc", "adapters/cursor/anti-slop.mdc"],
  ["cli/templates/SKILL.md", "skills/anti-slop/SKILL.md"]
]) {
  const c = read(copy), s = read(src);
  if (c === null) continue;
  check(s !== null && c === s, copy + " differs from " + src + " (regenerate: cp " + src + " " + copy + ")", copy + " matches " + src);
}

// 2. The spine must reference both bilingual protocol files.
const agentsTxt = agents || "";
for (const f of ["protocol/anti-ai-slop.en.md", "protocol/anti-ai-slop.id.md"]) {
  check(agentsTxt.includes(f), "AGENTS.md does not reference " + f, "AGENTS.md references " + f);
}

// 3. Both bilingual protocol files must exist (the Indonesian layer is a
//    deliberate surface; an edit to one must not silently leave the other behind).
for (const f of ["protocol/anti-ai-slop.en.md", "protocol/anti-ai-slop.id.md"]) {
  check(existsSync(join(root, f)), "protocol file missing: " + f, f + " present");
}

// Report.
if (problems.length) {
  console.error("DRIFT FOUND:\n - " + problems.join("\n - "));
  process.exit(1);
}
console.log("drift-check OK\n - " + ok.join("\n - "));
