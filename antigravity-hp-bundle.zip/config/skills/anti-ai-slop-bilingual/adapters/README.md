# Adapters

These adapters point a specific tool at the anti-AI-slop standard. They are distilled from the canonical standard under `protocol/`. If an adapter ever disagrees with `protocol/`, the protocol wins and the adapter is out of date.

- `cursor/anti-slop.mdc`: the Cursor rule. Install it into a project with `npx antislop cursor`, or copy it to `.cursor/rules/anti-slop.mdc`.

For Claude, the skill lives at `skills/anti-slop/SKILL.md` (install with `npx antislop skill`). For most other coding agents, drop `AGENTS.md` at the project root (`npx antislop init`). For a rule-based check engine, add the MCP server in `mcp/`.
