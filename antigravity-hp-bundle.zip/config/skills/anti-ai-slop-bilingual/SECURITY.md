# Security

The anti-AI-slop standard has two parts, and they take two reporting paths.

## The standard text

The standard is plain markdown you can read. If you find a way it could be misused, or a tampered copy circulating somewhere, open an issue. The text has no secret behavior, so these can be discussed openly and every reader benefits from the fix.

## The code that ships as a package

The `antislop-mcp` server and the `antislop` installer ship as npm packages that run on your machine. The MCP server makes no network calls and sends no telemetry; it only returns the standard it bundles and the check it computes locally. Read `server.mjs` and `antislop.mjs` before you trust them.

If you find a vulnerability in the code that should stay private until it is fixed, report it through GitHub Private Vulnerability Reporting on the repository (the Security tab, "Report a vulnerability"). That opens a private advisory visible only to you and the maintainer.

Response commitment for a solo-maintained project: acknowledgement within 7 days, and a fix or a published mitigation targeted within 90 days of a confirmed report. Supported version: the latest release. In either path, describe what you found and how to reproduce it.
