#!/usr/bin/env node
/*
  Anti-AI-slop MCP server. Exposes the anti-AI-slop standard to any MCP-capable
  coding agent: read the standard spine, check a piece of text against the
  rule-based engine, list the categories, and get the rules in one category. The
  engine flags MECHANICAL tells; the rewrite to natural is handed back to the
  agent via a ready-to-paste prompt. stdio transport, no network, no telemetry.

  This is an editorial STYLE scorer, not an authorship classifier and not a
  provenance checker. See the detection-claims discipline in the protocol.
*/
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { lint, rewritePrompt, CATEGORIES, ALL_RULES } from "./antislop.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const REPO = "https://github.com/dharmawan-id/anti-ai-slop";
function load(name) { try { return readFileSync(join(here, name), "utf8"); } catch { return ""; } }
const AGENTS = load("agents.md");

const server = new McpServer({ name: "anti-ai-slop", version: "0.1.0" });

server.tool(
  "antislop_overview",
  "Return the anti-AI-slop standard spine: what slop is, the remediation discipline (detect then rewrite to natural), the pattern categories (symbols, vocabulary, contrast and binary framing, false agency, cadence, sycophancy, the 2026 model-tell panel, Indonesian-specific tells), and the detection-claims discipline. Read this first before writing or editing text that must not read as AI-generated.",
  {},
  async () => ({ content: [{ type: "text", text: AGENTS || ("The anti-AI-slop standard is at " + REPO + "/blob/main/AGENTS.md") }] })
);

server.tool(
  "antislop_check",
  "Check a piece of text against the anti-AI-slop rule engine. Returns the mechanical tells found (symbols, banned vocabulary, contrast and binary framing, false agency, sycophancy, Indonesian calques and marketing cliches), an editorial style score (0 to 100, higher is cleaner), and a ready-to-paste prompt to rewrite the text to natural. The score is an editorial style signal, not an authorship verdict.",
  {
    text: z.string().describe("the text to check"),
    lang: z.enum(["en", "id", "both"]).optional().describe("which language's rules to apply (default both)"),
    severityMin: z.enum(["low", "med", "high"]).optional().describe("only report this severity and above (default low)")
  },
  async (a) => {
    const r = lint(a.text, { lang: a.lang || "both", severityMin: a.severityMin });
    const lines = r.findings.length
      ? r.findings.map((f) => "  L" + f.line + ":" + f.col + " [" + f.severity + "/" + f.category + "] " + f.message + ": \"" + f.match + "\"  -> " + f.fix).join("\n")
      : "  No mechanical tells caught. Still check the judgment-level patterns by reading the standard: cadence uniformity, perfect-rectangle paragraphs, synonym cycling, vague attribution, and whether it simply reads like a model wrote it.";
    const text =
      "Anti-AI-slop check\n==================\n\n" +
      "Words: " + r.words + "    Editorial style score: " + r.score + "/100 (higher is cleaner; this is a style signal, not an authorship verdict).\n" +
      "Findings: " + r.findings.length + " (high " + r.counts.high + ", med " + r.counts.med + ", low " + r.counts.low + ")\n\n" +
      lines + "\n\n" +
      "----- rewrite prompt (paste into your agent) -----\n\n" + rewritePrompt(a.text, r);
    return { content: [{ type: "text", text }] };
  }
);

server.tool(
  "antislop_list_categories",
  "List the anti-AI-slop pattern categories, each with a one-line note and how many rules the engine checks in it.",
  {},
  async () => {
    const byCat = {};
    ALL_RULES.forEach((r) => { byCat[r.cat] = (byCat[r.cat] || 0) + 1; });
    const text = CATEGORIES.map((c) => c.id + " (" + (byCat[c.id] || 0) + " rules): " + c.label + " -- " + c.note).join("\n");
    return { content: [{ type: "text", text }] };
  }
);

server.tool(
  "antislop_explain",
  "List the engine's rules in one category, by category id (for example symbol, vocabulary, semantic, false-agency, sycophancy, calque, marketing). Each rule shows its severity, what it flags, and the fix.",
  { category: z.string().describe("a category id from antislop_list_categories") },
  async (a) => {
    const key = String(a.category || "").trim().toLowerCase();
    const rules = ALL_RULES.filter((r) => r.cat === key);
    if (!rules.length) {
      return { content: [{ type: "text", text: "No category \"" + a.category + "\". Categories: " + CATEGORIES.map((c) => c.id).join(", ") + "." }] };
    }
    const text = key + " (" + rules.length + " rules)\n" + "=".repeat(key.length) + "\n" +
      rules.map((r) => "- [" + r.sev + "/" + r.lang + "] " + r.msg + "  -> " + r.fix).join("\n");
    return { content: [{ type: "text", text }] };
  }
);

await server.connect(new StdioServerTransport());
