/*
  Anti-AI-slop detection engine for the MCP server.
  Pure functions, no dependencies. Catches the MECHANICAL tells (symbols, banned
  vocabulary, structural patterns) that a regex can see reliably. The nuanced
  judgment (cadence, is-this-actually-natural) is handed to the calling agent via
  the rewrite prompt. This is an editorial STYLE scorer: it flags patterns
  regardless of who wrote the text. It is not an authorship classifier and not a
  provenance checker (see the detection-claims discipline in the protocol).

  The canonical, complete standard is /protocol/anti-ai-slop.en.md (+ .id.md).
  This engine encodes the rule-checkable subset, kept in the same spirit.
*/

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Simple word/phrase bans: matched case-insensitively at word boundaries.
// lang: "en" | "id" | "any". severity: "high" | "med" | "low".
const PHRASE_BANS = [
  // English current-era survivors + classic vocabulary (high signal)
  ["en", "high", "delve", "use a plain verb (look at, go into)"],
  ["en", "med", "leverage", "use \"use\" or \"apply\""],
  ["en", "med", "harness", "use \"use\""],
  ["en", "med", "foster", "use \"build\" or \"support\" (literal agriculture aside)"],
  ["en", "med", "utilize", "use \"use\""],
  ["en", "high", "showcasing", "show, or state it directly"],
  ["en", "high", "highlighting", "show, or state it directly"],
  ["en", "high", "emphasizing", "state it directly"],
  ["en", "med", "underscore", "show it, do not announce it"],
  ["en", "med", "robust", "only for literal infrastructure; otherwise be specific"],
  ["en", "med", "seamless", "only for literal UX; otherwise cut"],
  ["en", "med", "seamlessly", "only for literal UX; otherwise cut"],
  ["en", "med", "multifaceted", "cut, or name the actual facets"],
  ["en", "med", "holistic", "cut, or say what it covers"],
  ["en", "med", "synergy", "say what actually combines and how"],
  ["en", "med", "tapestry", "cut the metaphor"],
  ["en", "med", "realm", "use \"area\" or \"field\""],
  ["en", "med", "plethora", "use \"many\" or a number"],
  ["en", "med", "myriad", "use \"many\" or a number"],
  ["en", "med", "meticulous", "cut, or show the care concretely"],
  ["en", "med", "cutting-edge", "name what is actually new"],
  ["en", "med", "groundbreaking", "name what is actually new"],
  ["en", "med", "game-changer", "say what changes and for whom"],
  ["en", "high", "it's worth noting", "just state the thing"],
  ["en", "high", "it is worth noting", "just state the thing"],
  ["en", "high", "it's important to note", "just state the thing"],
  ["en", "high", "it is important to note", "just state the thing"],
  ["en", "low", "in today's", "name the actual time or cut"],
  // Indonesian (the wedge): high-signal vocabulary and connectors
  ["id", "high", "tidak dapat dipungkiri", "langsung nyatakan klaimnya"],
  ["id", "high", "tak dapat dipungkiri", "langsung nyatakan klaimnya"],
  ["id", "med", "krusial", "pakai \"penting\", atau sebut alasannya"],
  ["id", "med", "komprehensif", "sebut cakupannya"],
  ["id", "med", "holistik", "sebut apa yang dicakup"],
  ["id", "med", "optimalisasi", "pakai \"perbaikan\" atau sebut yang dioptimalkan"],
  ["id", "med", "sinergi", "sebut apa yang digabung dan caranya"],
  ["id", "med", "transformasi digital", "sebut perubahan konkretnya"],
  ["id", "med", "ekosistem", "sebut bagian-bagiannya"],
  ["id", "med", "lanskap", "pakai kata harfiah, atau sebut situasinya"],
  ["id", "med", "stakeholder", "pakai \"pemangku kepentingan\" atau sebut siapa"],
  ["id", "med", "menyoroti", "tunjukkan temuannya langsung"],
  ["id", "med", "menggarisbawahi", "nyatakan langsung"],
  ["id", "med", "memfasilitasi", "pakai \"membantu\""],
  ["id", "low", "selain itu", "lanjut saja ke poin berikutnya"],
  ["id", "low", "di sisi lain", "lanjut saja, atau pakai \"tapi\""],
  ["id", "low", "oleh karena itu", "pakai \"jadi\" atau restruktur"],
  ["id", "low", "dengan demikian", "pakai \"jadi\" atau restruktur"],
  ["id", "med", "di era modern ini", "buka dari situasi konkret"],
  ["id", "med", "seiring perkembangan zaman", "buka dari situasi konkret"],
  ["id", "high", "sebagai kesimpulan", "akhiri saja; isinya sudah jadi kesimpulan"],
  ["id", "high", "dapat disimpulkan bahwa", "nyatakan langsung tanpa pengantar"]
];

// Structural regex rules. Each `re` is global and written to avoid backtracking.
const REGEX_RULES = [
  { id: "em-dash", cat: "symbol", sev: "high", lang: "any", re: /\u2014/g, msg: "Em dash", fix: "use a comma, colon, parentheses, period, or restructure" },
  { id: "double-hyphen", cat: "symbol", sev: "med", lang: "any", re: /\s--\s|\w--\w/g, msg: "Double hyphen as an em-dash substitute", fix: "paraphrase; banned in published artifacts" },
  { id: "curly-quote", cat: "symbol", sev: "low", lang: "any", re: /[\u2018\u2019\u201c\u201d]/g, msg: "Curly quote (copy-paste fingerprint in plain-text contexts)", fix: "normalize to straight quotes where the context is plain text" },
  { id: "bold-colon-bullet", cat: "structure", sev: "high", lang: "any", re: /^\s*[-*]\s+\*\*[^*\n]{1,40}:\*\*/gm, msg: "Bold-first bullet (bold phrase + colon)", fix: "use prose or a plain bullet without the bold header" },
  { id: "transitional-stack", cat: "filler", sev: "med", lang: "any", re: /^\s*(Furthermore|Moreover|Additionally|In addition)\b/gm, msg: "Transitional filler opener", fix: "say the next point, or use a short connector (Also, And, But)" },
  { id: "contrast-not-but", cat: "semantic", sev: "high", lang: "en", re: /\bnot\s+(just|only|merely)\b[^.?!]{1,60}?,?\s+(but|it'?s|it is)\b/gi, msg: "Contrast / affirmative-pivot framing", fix: "state the affirmative directly with the concrete detail" },
  { id: "binary-isnt-its", cat: "semantic", sev: "high", lang: "en", re: /\b(it|this|that)\s?(?:is|'s)\s?n['o]t\s+(?:about\s+)?[^.?!]{1,40}?,\s+(?:it'?s|its)\b/gi, msg: "Binary / false-dichotomy framing", fix: "state the claim with its real conditions, not two poles" },
  { id: "contrast-bukan", cat: "semantic", sev: "high", lang: "id", re: /\bbukan\s+(sekadar|sekedar|hanya)\b/gi, msg: "Contrast framing (bukan sekadar X)", fix: "nyatakan yang afirmatif langsung dengan detail konkret" },
  { id: "turn-closer", cat: "sycophancy", sev: "med", lang: "en", re: /\b(would you like me to|let me know if you'?d like|if you'?d like,? i can|want me to (expand|dive))\b/gi, msg: "Turn-closer artifact", fix: "end the response where the content ends" },
  { id: "false-agency", cat: "false-agency", sev: "high", lang: "en", re: /\bthe\s+(data|report|study|chart|graph|research)\s+(tells|shows us|highlights|reveals to us|suggests to us)\b/gi, msg: "False agency (inanimate subject performs a human action)", fix: "name the human actor, or state the finding directly" },
  { id: "participle-padding", cat: "participle", sev: "med", lang: "en", re: /,\s+(highlighting|showcasing|emphasizing|underscoring|reflecting|ensuring|paving)\s+the\b/gi, msg: "Present-participle padding", fix: "cut the trailing -ing clause, or make it a real sentence" },
  { id: "significance-collocation", cat: "semantic", sev: "med", lang: "en", re: /\bplays?\s+an?\s+(crucial|key|pivotal|vital|significant|central)\s+role\b/gi, msg: "Fixed significance collocation", fix: "say what it does, specifically" },
  { id: "menjadi-elevation", cat: "semantic", sev: "low", lang: "id", re: /\bmenjadi\s+salah\s+satu\b/gi, msg: "\"menjadi salah satu\" false-elevation", fix: "nyatakan langsung: \"X adalah ...\" atau pakai sifat langsung" },
  { id: "yang-mana", cat: "calque", sev: "high", lang: "id", re: /\byang\s+mana\b/gi, msg: "\"yang mana\" calque (valid only as a question word)", fix: "pakai \"yang\" saja" },
  { id: "id-cta", cat: "marketing", sev: "med", lang: "id", re: /\b(yuk,?\s+(simak|intip|kepoin)|tunggu apa lagi|jangan sampai (ketinggalan|kehabisan)|buruan,?\s+sebelum)\b/gi, msg: "Formulaic Indonesian call-to-action", fix: "ajak dengan alasan konkret, bukan urgensi buatan" }
];

const compiled = PHRASE_BANS.map(([lang, sev, term, fix]) => ({
  id: "vocab:" + term.replace(/\s+/g, "-"),
  cat: "vocabulary",
  sev, lang, fix,
  msg: "Banned " + (lang === "id" ? "Indonesian " : "") + "phrase: \"" + term + "\"",
  re: new RegExp("\\b" + esc(term) + "\\b", "gi")
}));

const ALL_RULES = [...REGEX_RULES, ...compiled];

export const CATEGORIES = [
  { id: "symbol", label: "Symbol bans", note: "em dash, double hyphen, curly quotes" },
  { id: "vocabulary", label: "Vocabulary blacklist", note: "words that appear at many times the human rate (EN + ID)" },
  { id: "filler", label: "Transitional filler", note: "stacked Furthermore/Moreover and connector padding" },
  { id: "structure", label: "Structure", note: "bold-first bullets and formatting tells" },
  { id: "semantic", label: "Semantic patterns", note: "contrast framing, binary framing, significance collocations" },
  { id: "false-agency", label: "False agency", note: "inanimate subjects performing human actions" },
  { id: "participle", label: "Present-participle padding", note: "trailing -ing clauses for fake depth" },
  { id: "sycophancy", label: "Sycophancy and chat artifacts", note: "openers and turn-closers" },
  { id: "calque", label: "Indonesian calque", note: "English-shaped Indonesian (yang mana, di mana)" },
  { id: "marketing", label: "Marketing register", note: "formulaic Indonesian calls-to-action" }
];

const lineColOf = (text, index) => {
  let line = 1, last = 0;
  for (let i = 0; i < index; i++) if (text[i] === "\n") { line++; last = i + 1; }
  return { line, col: index - last + 1 };
};

// lint(text, opts) -> { findings, counts, score }
// opts.lang: "en" | "id" | "both" (default "both"). opts.severityMin: include only this and above.
export function lint(text, opts = {}) {
  const src = String(text || "");
  const wantLang = opts.lang === "en" ? ["en", "any"] : opts.lang === "id" ? ["id", "any"] : ["en", "id", "any"];
  const sevRank = { high: 3, med: 2, low: 1 };
  const minRank = sevRank[opts.severityMin] || 1;
  const findings = [];
  for (const rule of ALL_RULES) {
    if (!wantLang.includes(rule.lang)) continue;
    if (sevRank[rule.sev] < minRank) continue;
    rule.re.lastIndex = 0;
    let m, guard = 0;
    while ((m = rule.re.exec(src)) && guard++ < 5000) {
      const { line, col } = lineColOf(src, m.index);
      findings.push({ ruleId: rule.id, category: rule.cat, severity: rule.sev, line, col, match: m[0].slice(0, 80), message: rule.msg, fix: rule.fix });
      if (m.index === rule.re.lastIndex) rule.re.lastIndex++; // zero-width guard
    }
  }
  findings.sort((a, b) => a.line - b.line || a.col - b.col);
  const counts = { high: 0, med: 0, low: 0 };
  findings.forEach((f) => { counts[f.severity]++; });
  // Editorial style score: starts at 100, weighted deductions, floored at 0.
  const words = (src.match(/\S+/g) || []).length || 1;
  const penalty = counts.high * 6 + counts.med * 3 + counts.low * 1;
  const per1k = penalty / (words / 1000 || 1);
  const score = Math.max(0, Math.round(100 - Math.min(100, per1k)));
  return { findings, counts, words, score };
}

const REPO = "https://github.com/dharmawan-id/anti-ai-slop";

// rewritePrompt(text, result) -> a ready-to-paste prompt for the agent to do the
// nuanced rewrite the engine cannot (cadence, naturalness, real rephrasing).
export function rewritePrompt(text, result) {
  const flagged = result.findings.slice(0, 40).map((f) => "  L" + f.line + " [" + f.severity + "/" + f.category + "] " + f.message + ": \"" + f.match + "\" -> " + f.fix).join("\n");
  return (
    "Rewrite the text below to remove AI-slop, following the anti-AI-slop standard at " + REPO + " (read AGENTS.md for the full rules).\n\n" +
    "A rule-based pass flagged these mechanical tells (an editorial style signal, not an authorship verdict):\n" + (flagged || "  (no mechanical tells caught; check the judgment-level rules: cadence uniformity, perfect-rectangle paragraphs, synonym cycling, vague attribution)") + "\n\n" +
    "Rewrite to natural, keeping the real meaning. Do not just swap one tell for another: restructure. Vary sentence and paragraph length (mix short 3-to-8-word sentences with longer ones), state one clear claim per sentence, replace vague abstraction with concrete specifics, and remove every flagged pattern. Then re-read against the litmus test: does it still sound like a model wrote it? If yes, rewrite again. Return only the rewritten text.\n\n" +
    "----- text to rewrite -----\n" + String(text || "")
  );
}

export { ALL_RULES };
