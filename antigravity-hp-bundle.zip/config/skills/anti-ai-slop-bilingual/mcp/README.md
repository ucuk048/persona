# Anti-AI-slop MCP server

[![npm version](https://img.shields.io/npm/v/antislop-mcp)](https://www.npmjs.com/package/antislop-mcp)
![node](https://img.shields.io/badge/node-%3E%3D18-brightgreen)
![license](https://img.shields.io/badge/license-MIT-blue)

Run the anti-AI-slop standard as an MCP server, so any MCP-capable coding agent (Claude Code, Cursor, and others) can read the standard, check text against a rule engine, and get a rewrite prompt on demand, without you copying any files into your project.

It is a small stdio server. It makes no network calls and sends no telemetry. It only returns the standard and the check it computes locally. It is an editorial style scorer, not an authorship classifier and not a provenance checker.

## What it gives your agent

Four tools:

- `antislop_overview`: the standard spine: what slop is, the remediation discipline, the pattern categories, and the detection-claims discipline. Your agent reads this first.
- `antislop_check`: you pass text (and optionally a language and a minimum severity), and it returns the mechanical tells found, an editorial style score (0 to 100), and a ready-to-paste prompt to rewrite the text to natural.
- `antislop_list_categories`: the pattern categories, each with how many rules the engine checks.
- `antislop_explain`: the engine's rules in one category, with severity and the fix.

The engine catches the mechanical tells (symbols, banned vocabulary, contrast and binary framing, false agency, sycophancy, Indonesian calques and marketing cliches). Your agent adds the judgment the engine cannot: cadence, naturalness, and whether the rewrite still reads like a human wrote it.

## Install

Requirements: Node 18 or newer. No other setup, no API key, no account.

### From npm (once published)

Add this to your MCP client config (for Claude Code, `claude mcp add` or the `mcpServers` block; for Cursor, `.cursor/mcp.json`):

```json
{
  "mcpServers": {
    "anti-ai-slop": { "command": "npx", "args": ["-y", "antislop-mcp"] }
  }
}
```

### From source (works now, before publishing)

Clone the repo, install once, and point your client at the server file:

```bash
git clone https://github.com/dharmawan-id/anti-ai-slop
cd anti-ai-slop/mcp && npm install
```

```json
{
  "mcpServers": {
    "anti-ai-slop": { "command": "node", "args": ["/absolute/path/to/anti-ai-slop/mcp/server.mjs"] }
  }
}
```

## A note on what this is

This server scores editorial style: it flags patterns regardless of who wrote the text. It does not detect authorship and does not verify provenance. Do not use its score to claim a specific person used AI. Read `server.mjs` and `antislop.mjs` before you trust them.

## Support

- Questions or bugs: open an issue at [github.com/dharmawan-id/anti-ai-slop/issues](https://github.com/dharmawan-id/anti-ai-slop/issues).
- A security problem in the code: see [SECURITY.md](https://github.com/dharmawan-id/anti-ai-slop/blob/main/SECURITY.md) for the private reporting path.
- The full standard, English and Indonesian, lives in the [main repository](https://github.com/dharmawan-id/anti-ai-slop).

## License

MIT (this folder is code). The standard text it serves is CC-BY-4.0. The `agents.md` in this folder is a bundled copy of the repo's `AGENTS.md`; regenerate it with `cp ../AGENTS.md agents.md` when the standard changes.
