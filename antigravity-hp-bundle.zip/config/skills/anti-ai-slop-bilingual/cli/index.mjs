#!/usr/bin/env node
/*
  antislop: install the anti-AI-slop standard into your project.
  Zero dependencies. Copies bundled templates into the right place.
*/
import { existsSync, mkdirSync, cpSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
const T = join(here, "templates");
const cwd = process.cwd();
const args = process.argv.slice(2);
const cmd = (args[0] || "").toLowerCase();
const force = args.includes("--force");
const REPO = "https://github.com/dharmawan-id/anti-ai-slop";

function place(src, dest, label) {
  const d = join(cwd, dest);
  if (existsSync(d) && !force) { console.log("skipped: " + dest + " already exists (use --force to overwrite)"); return; }
  mkdirSync(dirname(d), { recursive: true });
  cpSync(join(T, src), d);
  console.log("added: " + dest + "  (" + label + ")");
}

function agents() { place("AGENTS.md", "AGENTS.md", "the standard spine, read by most coding agents"); }
function cursor() { place("anti-slop.mdc", ".cursor/rules/anti-slop.mdc", "Cursor adapter"); }
function skill() { place("SKILL.md", ".claude/skills/anti-slop/SKILL.md", "Claude skill"); }

const help = [
  "antislop: install the anti-AI-slop standard into your project.",
  "",
  "  npx antislop init      drop AGENTS.md into this folder (works with most coding agents)",
  "  npx antislop cursor    add the Cursor adapter (.cursor/rules/anti-slop.mdc)",
  "  npx antislop skill     add the Claude skill (.claude/skills/anti-slop/)",
  "  npx antislop all       do all three",
  "  --force                overwrite files that already exist",
  "",
  "Then ask your coding agent to remove the AI slop from a draft, or run a check.",
  "For a rule-based check engine, add the MCP server (antislop-mcp).",
  "Full standard (English + Indonesian): " + REPO
].join("\n");

switch (cmd) {
  case "init": agents(); console.log("\nNext: ask your agent to de-slop a draft. For Cursor, run antislop cursor; for Claude, antislop skill."); break;
  case "cursor": cursor(); break;
  case "skill": skill(); break;
  case "all": agents(); cursor(); skill(); break;
  default: console.log(help);
}
