# antislop (CLI)

[![npm version](https://img.shields.io/npm/v/antislop)](https://www.npmjs.com/package/antislop)
![node](https://img.shields.io/badge/node-%3E%3D18-brightgreen)
![license](https://img.shields.io/badge/license-MIT-blue)

Install the anti-AI-slop standard into your project with one command. No dependencies.

Requirements: Node 18 or newer. Nothing else, no API key, no account.

## Use

```bash
npx antislop init      # drop AGENTS.md into this folder (works with most coding agents)
npx antislop cursor    # add the Cursor adapter (.cursor/rules/anti-slop.mdc)
npx antislop skill     # add the Claude skill (.claude/skills/anti-slop/)
npx antislop all       # do all three
```

Add `--force` to overwrite files that already exist.

After installing, ask your coding agent to remove the AI slop from a draft, or to check whether text reads as machine-written. For a rule-based check engine (a programmatic first pass), add the MCP server, `antislop-mcp`.

The templates in this package are copies of the repo's `AGENTS.md`, `adapters/cursor/anti-slop.mdc`, and `skills/anti-slop/SKILL.md`. The repo's drift-check (`scripts/check-drift.mjs`) keeps them identical to the source.

## Support

- Questions or bugs: open an issue at [github.com/dharmawan-id/anti-ai-slop/issues](https://github.com/dharmawan-id/anti-ai-slop/issues).
- A security problem in the code: see [SECURITY.md](https://github.com/dharmawan-id/anti-ai-slop/blob/main/SECURITY.md) for the private reporting path.
- The full standard, English and Indonesian, lives in the [main repository](https://github.com/dharmawan-id/anti-ai-slop).

## License

MIT (this is code). The standard text it installs is CC BY 4.0. See the repo root.
