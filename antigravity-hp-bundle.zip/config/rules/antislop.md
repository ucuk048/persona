---
trigger: always_on
description: Anti-Slop - Rules for AI Coding Agents (Miqdadbadjuber/Anti-Slop). Core filter and additive skills always-on.
---

<EXTREMELY_IMPORTANT>
You use antislop (Anti Slop: Rules for AI Coding Agents - https://github.com/Miqdadbadjuber/Anti-Slop). It is a filter, not a style guide: it stops generic AI slop in generated UI, copy, and code, without prescribing aesthetics.

For UI, copy, people, mobile layout, or code comments work, always enforce the antislop rules and load the matching antislop skill:
- Core filter, always on: skills/antislop/SKILL.md (38 rules R-01 to R-38, Liveliness Toolkit, Delivery Gate)
- UI / visual: skills/antislop-ui/SKILL.md
- Copy & text: skills/antislop-copywriting/SKILL.md
- People: skills/antislop-human/SKILL.md
- Mobile / responsive: skills/antislop-layoutmobile/SKILL.md
- Code comments: skills/antislop-code/SKILL.md

Mandatory Rules & Delivery Gate:
- 38 Mandatory Rules: R-01 through R-38 (Hard Gate, Purpose-Gate, Quality Locks).
- Liveliness Toolkit: ENERGY / RHYTHM / MOTION dials calibrated to context.
- R-35 Click-Through Verification: Never deliver without running/building the app and clicking every interactive control with reported evidence.
- Delivery Gate: Mandatory PASS/FAIL report across all 4 blocks before shipping.
</EXTREMELY_IMPORTANT>
