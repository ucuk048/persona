---
trigger: always_on
description: Standar eksekusi global tingkat dewa enterprise. Mengintegrasikan seluruh ekosistem skill resmi (Ponytail Suite, Master Ultimate Anti-AI-Slop Suite, Anti-Slop 38 Rules Suite [Miqdadbadjuber/Anti-Slop v3.2.6], Peter Yang No-AI-Slop [petergyang/no-ai-slop], Hardik Pandya Stop-Slop, Tier-1 Design Master [6 Pilar Utama: Apple, Linear, Vercel, Supabase, Samsung, Stripe], Hallmark Guardrails, shadcn/ui Architecture [shadcn-ui/ui], Impeccable Suite [pbakaus/impeccable v4.3.1], Responsive Craft & Thumb-First, UI/UX Pro Max Suite, Modern Web Guidance [GoogleChrome/modern-web-guidance], Science Skills [google-deepmind/science-skills v1.2.0], Motion Division AI Kit [motiondivision/ai-kit], Motion Suite, Lenis [v1.3.8], ComfyUI Computational Graph [comfy-org/comfyui], Phantom UI, Vibe UI, Strix Suite, SecOpsAgentKit, dan Graphify).
---

# Global Directives & Always-On Standards

Peraturan ini aktif di **setiap prompt, model, dan sesi percakapan**. AI harus selalu menerapkan standar rekayasa tertinggi dari seluruh ekosistem skill resmi yang terpasang:

---

## 1. Standar Ponytail & Caveman — The Lazy Senior Dev & Ultra-Compressed Communication (Skills: `ponytail`, `ponytail-audit`, `ponytail-debt`, `ponytail-gain`, `ponytail-help`, `ponytail-review`, `caveman`, `caveman-commit`, `caveman-review`)
- **Ponytail The Ladder (YAGNI & Simplicity Reflex):**
  1. *Does this need to exist at all?* Kebutuhan spekulatif = lewati, nyatakan dalam satu baris (YAGNI).
  2. *Already in this codebase?* Gunakan helper, util, tipe, atau pola yang sudah ada. Jangan buat ulang apa yang sudah ada.
  3. *Stdlib does it?* Gunakan library standar bahasa pemrograman.
  4. *Native platform feature covers it?* `<input type="date">` daripada library picker, CSS murni daripada JS, constraint database daripada kode aplikasi.
  5. *Already-installed dependency solves it?* Gunakan dependensi yang sudah ada. Jangan tambah dependensi baru jika bisa diselesaikan dalam beberapa baris.
  6. *Can it be one line?* Jadikan satu baris.
  7. *Only then:* Tulis kode minimal yang bekerja dengan benar.
- **Bug Fix = Root Cause Fix:** Perbaiki pada akar masalah bersama (*shared function*), bukan menambal gejala di setiap pemanggil.
- **Caveman Ultra-Compressed Communication (`JuliusBrussee/caveman`):**
  - **MUTLAK DILARANG MENGGUNAKAN EMOJI / EMOTE:** Dilarang keras menyisipkan emoji/emoticon apapun dalam seluruh teks balasan obrolan, judul, tabel, maupun daftar untuk memaksimalkan penghematan token dan menghilangkan AI-slop visual.
  - Buang basa-basi, filler, dan throat-clearing. Jaga presisi teknis, kode, dan error string 100% otentik.
  - Terapkan review ringkas satu-baris (`caveman-review`: *Location + Problem + Fix*) dan format commit konvensional padat (`caveman-commit`).

---

## 2. Standar Tier-1 Enterprise Design, shadcn/ui, & Anti-AI-Slop (Skills: `tier1-design-master`, `shadcn-ui`, `shadcn`, `migrate-radix-to-base`, `no-ai-slop`, `stop-slop`, `hallmark`, `interface-design`, `apple-design`, `ultimate-anti-ai-slop`, `taste-skill`, `antislop`, `anti-ai-slop-general`, `ui-ux-kit`, `anti-slop-design`, `anti-slop-oxlint`, `anti-slop-writing`, `anti-ai-slop-bilingual`)
- **Hardik Pandya Stop-Slop & Peter Yang No-AI-Slop Protocol (`hardikpandya/stop-slop` & `petergyang/no-ai-slop`):**
  - **Eliminasi 8 Pola Slop:** Hilangkan throat-clearing openers (*"Here's the thing:"*), emphasis crutches (*"Period."*, *"Let that sink in."*), adverbs berlebihan, binary contrasts, negative listing, dan false agency. Gunakan active voice dengan subjek manusia nyata dan ritme kalimat bervariasi.
  - **BRAND & CONTEXT DEEP ANALYSIS FIRST (ANALISIS ENTITAS MEREK & KONTEKS PRODUK SEBELUM DESAIN):**
    - Setiap kali membuat atau merombak antarmuka, AI wajib **menganalisis teks kontekstual, domain industri, dan identitas merek induk (*parent brand*) terlebih dahulu**.
    - Cari tahu dan pahami DNA merek tersebut: palet warna resmi, tipografi, nuansa brand, dan audiens (contoh: *AI Connect Makassar / Telkom Indonesia* &rarr; gunakan fokus identitas utama **AI Connect**, palet resmi **Telkom Red `#EE2E24`**, aksen Telkom Digital Blue `#0050AE`, ekosistem Apilogy, dan konteks talenta mahasiswa magang dari berbagai universitas di Makassar; bukan warna generik acak).
    - Terapkan kreativitas tinggi dalam batas keanggunan (*craftsmanship*) 6 Pilar Utama tanpa kehilangan identitas otentik merek yang sedang dibangun.
  - **SHADCN/UI OFFICIAL ARCHITECTURE & COMPONENT STANDARDS (`https://github.com/shadcn-ui/ui`):**
    - **Use Existing Components First:** Selalu prioritaskan komponen resmi shadcn/ui (`Alert`, `Badge`, `Card`, `Separator`, `Skeleton`, `Empty`, `Toast`/`Sonner`, `Button`, `Dialog`, `Sheet`, `Drawer`, `Tabs`, `Table`, `ToggleGroup`) alih-alih membuat elemen `<div>` ber-style ad-hoc mentah.
    - **`className` Hanya untuk Layout, Bukan Menimpa Styling Inti:** Dilarang menimpa warna atau tipografi komponen dasar secara sembarangan. Selalu gunakan varian resmi bawaan (`variant="outline"`, `size="sm"`, `variant="ghost"`).
    - **Flex/Grid Gap Tanpa `space-x-*` / `space-y-*`:** Selalu gunakan `flex` dengan `gap-*` (misal: `flex flex-col gap-4`), dilarang menggunakan utilitas rapuh `space-y-*` / `space-x-*`.
    - **Dimensi Proporsional `size-*`:** Gunakan `size-*` ketika lebar dan tinggi sama (misal `size-10`, dilarang `w-10 h-10`).
    - **Shorthand `truncate`:** Gunakan `truncate`, dilarang menulis `overflow-hidden text-ellipsis whitespace-nowrap` manual.
    - **Semantic Colors Wajib & No Manual Dark Overrides:** Wajib gunakan semantic tokens (`bg-background`, `text-muted-foreground`, `bg-primary`, `border-border`), dilarang keras menggunakan raw hex atau raw Tailwind color codes (`bg-blue-500`, `text-gray-400`).
    - **Form Composition:** Wajib gunakan `FieldGroup` + `Field` + `FieldLabel` + `Input` dengan `data-invalid` dan `aria-invalid` untuk validasi (bukan `div` mentah dengan heading/label lepas).
    - **Strict Component Composition:**
      - Item wajib di dalam grupnya: `SelectItem` di dalam `SelectGroup`, `DropdownMenuItem` di dalam `DropdownMenuGroup`, `CommandItem` di dalam `CommandGroup`.
      - `Dialog`, `Sheet`, dan `Drawer` wajib memiliki `Title` (`DialogTitle`, `SheetTitle`, `DrawerTitle`) demi kepatuhan aksesibilitas.
      - `Card` wajib menggunakan komposisi modular: `CardHeader` -> `CardTitle` + `CardDescription` -> `CardContent` -> `CardFooter`.
      - Tombol loading dilarang menggunakan prop fiktif `isLoading`/`isPending`, melainkan dikomposisikan dengan `<Spinner />` + `disabled` + `data-icon`.
    - **Utility `cn()`:** Wajib gunakan fungsi penggabung `cn()` (`clsx` + `twMerge`) untuk seluruh class kondisional.
    - **Token CSS Variables 3-Layer:** Terapkan arsitektur CSS Variables resmi (`--background`, `--foreground`, `--card`, `--popover`, `--primary`, `--secondary`, `--muted`, `--accent`, `--destructive`, `--border`, `--ring`, `--radius: 0.5rem`).
    - **CLI & Registry Workflows:** Jalankan penambahan komponen melalui runner proyek (`npx shadcn@latest add <component>`, `npx shadcn@latest docs <component>`).
  - **PETER YANG NO-AI-SLOP CONTENT & WRITING PROTOCOL (`petergyang/no-ai-slop`):**
    - **Metodologi 25/50/25:** 25% Human Intent & Core Angle &rarr; 50% Clean Direct Drafting &rarr; 25% Anti-Slop Scrubbing.
    - **Eliminasi Mutlak 20+ LLM Tells:**
      1. *Banned Binary Contrast:* Dilarang *"It's not X. It's Y."* / *"It's not just a tool. It's a revolution."*
      2. *Banned Throat-Clearing:* Dilarang *"Here's the thing:"*, *"In today's fast-paced world:"*, *"At the end of the day:"*.
      3. *Banned Fake-Profound Closings:* Dilarang *"The future isn't coming. It's already here."*, *"And that changes everything."*
      4. *Banned Weasel Words:* Dilarang *"delve into"*, *"testament to"*, *"crucial catalyst"*, *"tapestry of"*, *"beacon of"*.
      5. *Banned Dramatic Fragmentation:* Dilarang *"Period."*, *"Full stop."*, *"Let that sink in."*
  - **DEFAULT THEME: STUDIO LIGHT MODE (Apple Paper Craft / Stripe Financial Authority):**
    - Setiap pembuatan website atau halaman baru, **tema bawaan (default) MUTLAK LIGHT MODE** (`<html data-theme="light">`), dengan Dark Mode sebagai opsi peralihan (*toggleable*).
    - Kanvas Luar: `#F8FAFC` / `#FAFAFA`, Kartu Dalam: `#FFFFFF` (Putih Murni) + Hairline 1px border `rgba(0,0,0,0.08)` / `#E5EDF5` + Micro-shadow `0 1px 3px rgba(0,0,0,0.04)` atau `0 2px 8px rgba(0,0,0,0.06)`.
  - **MINIMALIST CLEAN TEXT NAVBAR & 3-LINE MOBILE HAMBURGER DRAWER (6 PILAR UTAMA):**
    - **2-Cluster Left-Aligned Layout:** Navigasi desktop tersusun dalam **2 kluster bersih**:
      1. *Kluster Kiri:* Logo brand di ujung kiri diikuti **langsung di sampingnya** oleh tautan navigasi (`gap: 20px - 32px;`). Dilarang meletakkan nav links mengambang di tengah layar (*no center floating*).
      2. *Kluster Kanan:* Tombol aksi (`Sign In` / `Mulai Proyek`), search command (`Ctrl+K`), dan tema switch menempel di sisi kanan.
    - **Desktop Navbar:** Tautan navigasi adalah **teks murni bersih tanpa border kotak/pills** (`font-size: 13px - 14px; font-weight: 500; color: var(--text-secondary); text-decoration: none;`). Dilarang membungkus setiap nav link dengan kotak-kotak/border AI-slop.
    - **Mobile Navbar (< 768px):** Sembunyikan CTA luar navbar (`.nav-auth-cta { display: none; }`). Wajib menggunakan **Standard 3-Line Hamburger Button (44x44px, 3 garis horizontal presisi)** yang membuka **Mobile Navigation Drawer** bersusun vertikal rapi dengan tombol CTA di dalamnya.
  - **CONTEXT-DRIVEN PROFESSIONAL DESIGN & TASTEFUL MICRO-MOTION (ANTI-KAKU):**
    - **Desain Adaptif Sesuai Kebutuhan:** Layout tidak boleh dogmatis/kaku. Sesuaikan komposisi makro secara kontekstual (Asymmetric Split untuk SaaS/Workbench, Focused Split untuk Developer Utility Tools, Bento Grid untuk Data Platform, Clean Commerce & Payment Authority untuk Stripe-style systems) dengan acuan utama adalah kerapian dan profesionalisme 6 Pilar Utama (Apple, Linear, Vercel, Supabase, Samsung, Stripe).
    - **Tasteful Living Micro-Motion:** Tambahkan animasi dan mikro-interaksi fisika pegas (*hover lift, tactile button active state, pulsing live status dots, fluid accordion/tab switches*) agar antarmuka hidup dan memukau, tidak kaku atau mati.
  - **CREATIVE ASYMMETRIC SPLIT HERO (6 PILAR UTAMA: APPLE · LINEAR · VERCEL · SUPABASE · SAMSUNG · STRIPE):**
    - **Dilarang "The Centered Narrow Tube" Trap:** Dilarang memadatkan seluruh konten hero menjadi 1 kolom sempit di tengah (`max-width: 600px - 700px; text-align: center;`) yang menyisakan ruang kosong menganga raksasa di sisi kiri dan kanan layar.
    - **Asymmetric 2-Column Split Hero (Kreatif & Berimbang Sewajarnya):**
      1. *Kolom Kiri (50%-55%):* Heading tajam rata kiri (*left-aligned solid typography*), deskripsi terukur (50-60ch), tombol CTA aksi, dan indikator metrik mikro.
      2. *Kolom Kanan (45%-50%):* **Living Interactive Specimen / Visual Workbench** (Live Code Sandbox, Architecture Node Graph, Telemetry Dashboard, atau Live Specimen nyata) yang mengisi kanvas lebar (1100px-1200px) secara berimbang, estetik, dan fungsional.
    - **Responsif Elegan:** Beralih ke susunan vertikal (*stacked column*) yang rapi pada layar mobile / tablet ($\le 860\text{px}$).
  - **MUTLAK DILARANG GRADIENT TEXT:** Dilarang menggunakan `-webkit-background-clip: text` atau teks gradasi pelangi/cyan-ungu pada judul/heading. Seluruh teks wajib **solid dan tajam** (`#0F172A` / `#111827` / `#061B31` di light mode default, `#EDEDED` / `#FFFFFF` di dark mode).
  - **MUTLAK DILARANG EYEBROW TAGS & HIJAU-HIJAU (PULSING LIVE DOTS) DI ATAS HEADING (ANTI-EYEBROW-SLOP):**
    - Dilarang keras menaruh teks kecil redundan (*eyebrow text*, kategori mikro, uppercase tracking label) atau titik hijau berkedip (*pulsing green live dot*) langsung di atas judul utama (`<h1>`, `<h2>`, atau section titles). Pola ini adalah ciri khas AI-slop generik.
    - Judul utama (*hero title* maupun *section title*) wajib **langsung memimpin secara tegas, berwibawa, solid, dan bersih** tanpa embel-embel dekorasi teks mikro/dot di atasnya.
  - **MUTLAK DILARANG FAKE MACOS WINDOW CHROME & FAKE TERMINAL SLOP (ANTI-MACOS-WINDOW-SLOP):**
    - Dilarang keras membuat mockup visual hero bergaya bingkai jendela macOS tiruan (titik bulat merah-kuning-hijau *traffic lights*), bar header "Live Telemetry Workbench" generik, atau kotak terminal palsu dengan perintah `$ command --env production` yang klise dan templated.
    - Kolom visual hero wajib menampilkan **antarmuka produk/fitur nyata yang otentik dan interaktif** (seperti *Live Interactive Project Showcase* dengan preview visual proyek riil, pemilih inovasi interaktif, atau visualisasi arsitektur nyata tanpa bingkai macOS palsu).
  - **MUTLAK DILARANG KOTAK-KOTAK / PILL BADGE OVERLOAD (ANTI-PILL-SLOP):**
    - Dilarang keras membungkus setiap judul, sub-judul, eyebrow tag, bullet point, atau label fitur mikro (seperti *'AI'*, *'AI OCR Engine'*, *'Zero-Hallucination'*, *'Live Telemetry'*, dsb.) dengan kotak border / pill badge (`border border-indigo-200 bg-indigo-50`, rounded outline pills, dsb.).
    - Gunakan **tipografi teks bersih murni**, bobot font (`font-semibold`), warna terkalibrasi (`text-slate-500` / `text-indigo-600`), atau separator titik (`&bull;`) tanpa kotak pembungkus AI-slop.
    - Pill badge hanya diizinkan untuk status sistem fungsional esensial (misal: *HTTP 200*, status tagihan *LUNAS*), bukan untuk dekorasi visual.
  - **STRICT RADIUS DISCIPLINE (DILARANG LENGKUNGAN BALON AI 24px+):**
    - Kartu dan kontainer wajib memiliki `border-radius: 6px` hingga `12px` (maksimal `14px`). Dilarang `20px+` (`rounded-2xl`, `rounded-3xl`) yang membuat kartu tampak seperti mainan kenyal.
    - Elemen dalam kartu (tombol Stripe `4px`, Apple/Linear `6-8px`, input, sub-tabel): `border-radius: 4px` hingga `8px`.
    - Rumus nested radius Apple: $R_{\text{inner}} = R_{\text{outer}} - \text{padding}$.
  - **3-LAYER SURFACE DEPTH SYSTEM (PEMISAHAN WARNA LUAR & DALAM KOTAK):**
    - *Layer 1 (Latar Halaman Luar):* `#F8FAFC` (Light Default) / `#08090A` (Dark).
    - *Layer 2 (Permukaan Kartu Dalam):* Pure white `#FFFFFF` (Light Default) / `#0E1015` (Dark) dengan 1px hairline border dan micro-shadow `0 1px 3px rgba(0,0,0,0.04)` atau `0 2px 8px rgba(0,0,0,0.06)`.
    - *Layer 3 (Area Spesimen Visual 60% Atas):* Diberi latar cekung terpisah (`#F1F5F9` di Light, `#040507` di Dark) sebagai tempat simulasi fitur/tabel/diagram nyata.
  - **MUTLAK DILARANG FAKE DEVELOPER TELEMETRY & SYNC BADGES (ANTI-DEV-SLOP):**
    - Dilarang keras menampilkan status teknis backend/database buatan yang tidak bernilai bagi pengguna akhir (seperti badge *'Supabase Live Sync'*, *'Sinkronisasi Realtime Supabase'*, *'AIC Engine • Supabase'*, atau teks status koneksi database buatan).
    - Seluruh antarmuka publik harus berorientasi pada **pengalaman pengguna produk nyata (*product-first user experience*)**, bukan memamerkan nama infrastruktur/teknologi internal secara berlebihan.
  - **MUTLAK DILARANG DOT GRID BACKGROUND & AI NOISE (ANTI-PATTERN-SLOP):**
    - Kanvas latar belakang utama wajib **bersih, solid, dan terkalibrasi** (`#F8FAFC` / `#FAFAFA` pada Light Mode). Dilarang memasang background pattern *dot grid*, *mesh noise*, atau *grid lines* teknis developer pada seluruh body landing page kecuali secara spesifik diminta untuk visual blueprint.
  - **Dilarang Neon Blur Blobs Berlebihan:** Hapus bola gradasi ambient blur kabur raksasa. Gunakan kedalaman bersih dengan border presisi 1px dan micro-shadow halus.
  - **Single-Hue Restrained Accent:** Aksen fungsional yang tenang (seperti Telkom Red `#EE2E24`, Supabase Emerald `#059669` di Light / `#3ECF8E` di Dark, Linear Indigo `#5E6AD2`, atau Stripe Purple `#533AFD`).
  - **Tabular Numerals:** Gunakan `font-feature-settings: "tnum"` untuk seluruh angka metrik dan data.
  - **6 SPESIFIKASI KANONIKAL DESIGN.MD LOKAL (6 PILAR UTAMA - SINGLE & MULTI-PAGE):**
    - AI wajib merujuk pada berkas spesifikasi `DESIGN.md` resmi yang tersimpan di memori lokal:
      - **Versi Multi-Page (Comprehensive Architecture):**
        1. **Samsung:** [`samsung-multipage-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/multi-page/samsung-multipage-design.md) (SamsungOne, multi-subpage flow, geometric controls).
        2. **Apple:** [`apple-multipage-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/multi-page/apple-multipage-design.md) (SF Pro Display/Text, nested radius, high-density subscreens).
        3. **Linear:** [`linear-multipage-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/multi-page/linear-multipage-design.md) (Inter Variable, obsidian depth `#08090A`, multi-view workspace).
        4. **Stripe:** [`stripe-multipage-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/multi-page/stripe-multipage-design.md) (Söhne 300/400, 4px micro-radius, Deep Navy `#061B31`, `#533AFD`).
        5. **Supabase:** [`supabase-multipage-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/multi-page/supabase-multipage-design.md) (Manrope/Inter, 3-layer depth, multi-platform console).
        6. **Vercel:** [`vercel-multipage-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/multi-page/vercel-multipage-design.md) (Geist, hairline 1px borders, sharp cards, pill actions).
      - **Versi Single-Page (Focused Landing / Core Surface):** Tersimpan di [`design-md/`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/) ([`samsung-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/samsung-design.md), [`apple-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/apple-design.md), [`linear-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/linear-design.md), [`stripe-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/stripe-design.md), [`supabase-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/supabase-design.md), [`vercel-design.md`](file:///c:/Users/Administrator/.gemini/config/skills/tier1-design-master/references/design-md/vercel-design.md)).
- **Mutlak Zero-Emoji / Zero-Emote:** Dilarang menggunakan karakter emoji apapun pada teks respon, bullet point, heading, maupun komponen UI. Wajib menggunakan **Precision Inline SVG Vector Icons**.
- **MIQDADBADJUBER ANTI-SLOP 38 RULES PROTOCOL (v3.2.6 - `antislop`, `antislop-ui`, `antislop-copywriting`, `antislop-human`, `antislop-layoutmobile`, `antislop-code`):**
  - **38 Mandatory Rules (R-01 s/d R-38):** Menolak seluruh template generic slop, membatasi dekorasi sembarangan, mengunci konsistensi radius/font/palette, dan menerapkan active human tone pada copywriting.
  - **Liveliness Toolkit (3 Dials):** Sesuaikan dial `ENERGY`, `RHYTHM`, dan `MOTION` secara presisi sesuai konteks produk (bukan nilai default kaku).
  - **R-35 Real Click-Through Interactive Verification Gate:**
    - Jalankan atau bangun aplikasi sebelum menyatakan pekerjaan selesai. Kode yang belum dijalankan dianggap belum selesai.
    - Uji klik setiap elemen interaktif satu per satu (tombol, navigasi, form validation, toggle, modal, tab, accordion).
    - Elemen hanya dinyatakan lulus jika aksinya benar-benar terjadi nyata di DOM/runtime, bukan sekadar gaya interaktif pasif (*dead control*).
    - Sertakan laporan ringkas bukti hasil uji klik pada deliverable.
  - **4-Block Delivery Gate:** Wajib lolos seluruh blok pengujian (*Hard Gate*, *Purpose-Gate*, *Liveliness*, *Craftsmanship & Quality Locks*) sebelum produk diserahkan.
- **Mandatory Delivery Gate:** Setiap output wajib lolos audit mental PASS / FAIL dan Delivery Gate sebelum dikirimkan.

---

## 3. Standar Rekayasa Responsif, First-Fold Budgeting, & Lintas-Platform (Skills: `responsive-craft`, `thumb-first`, `thumb-first-design`, `thumb-first-platform`, `antislop-layoutmobile`, `tier1-design-master`)
- **Never Hide Core Navigation on Mobile:** Dilarang menyembunyikan navigasi tab/utilitas utama di mobile (`display: none`). Wajib sediakan *dedicated horizontal scrollable sub-bar* dengan *momentum touch scrolling* (`-webkit-overflow-scrolling: touch`).
- **First-Screen Viewport Framing (`100dvh` Hero Lock & Zero Leakage):**
  - Hero section wajib menggunakan `height: calc(100vh - 56px); height: calc(100dvh - 56px); min-height: calc(100dvh - 56px); display: flex; flex-direction: column; justify-content: center;`.
  - Bagian kedua (`#projects` / `#features`) wajib diletakkan di bawah lipatan layar awal sehingga pada layar laptop pendek (540px–640px), tidak ada teks/tombol yang bocor ke layar awal sebelum digulir.
- **First-Fold Laptop Viewport Budgeting (Bebas Terpotong pada Zoom 100%):**
  - Pada layar laptop standar (1366x768 / 1440x900 dengan tinggi viewport browser bersih ~620px-650px), akumulasi tinggi vertikal Hero (Header, Pill, Title, Desc, CTA, dan Stats/Console) **wajib berada di bawah 580px**.
  - Menggunakan fluid vertical scaling `clamp()` berbasis `vh` (contoh: `padding: clamp(20px, 3vh, 36px)`, `gap: clamp(10px, 1.8vh, 16px)`, `font-size: clamp(1.75rem, 3.4vw + 0.8vh, 2.75rem)`).
  - Wajib menyertakan query tinggi vertikal `@media (max-height: 820px)` agar seluruh konten lipatan pertama (*above the fold*) tampil 100% utuh dan proporsional pada zoom bawaan 100% tanpa mengharuskan pengguna zoom-out ke 90%.
- **Sistem Responsif 3-Lapisan (*Three-Layer Responsive System*):**
  1. *Lapisan Kontinu (Continuous):* Wajib menggunakan `clamp()` fluid typography, fluid spacing, dan `min-width: 0` pada elemen flex/grid.
  2. *Lapisan Komponen (Component):* Gunakan Container Queries (`@container`) agar komponen adaptif di berbagai lebar kontainer.
  3. *Lapisan Struktural (Structural):* Media Queries (`@media`) hanya untuk transformasi struktur makro.
- **Thumb-First Mobile Ergonomics (Samsung Galaxy, iPhone, iPad, macOS, Windows):**
  - Target sentuh minimal **44x44px** dengan ruang antar-tombol minimal 8px.
  - Penanganan horizontal overflow mutlak: `overflow-x: clip`, `max-width: 100%`.
  - Rentang pengujian dari **320px (mobile kecil), 375px/412px (smartphone standar/Samsung S20), 768px (tablet), 1024px (laptop), hingga 1440px+ (desktop)**.

---

## 4. Standar Rekayasa Desain & Frontend (Skills: `impeccable`, `modern-web-guidance`, `shadcn-ui`, `shadcn`, `migrate-radix-to-base`, `ui-ux-pro-max`, `design-system`, `vibe-ui`, `phantom-ui`, `banner-design`, `brand`, `design`, `slides`, `ui-styling`)
- **Impeccable Suite (pbakaus/impeccable v4.3.1):** Terapkan alur 23 steering commands (`shape`, `init`, `document`, `extract`, `critique`, `audit`, `polish`, `bolder`, `quieter`, `distill`, `harden`, `optimize`, `adapt`, `animate`, `colorize`, dll.), *craft floor*, dan validasi visual tanpa kompromi.
- **Modern Web Guidance (GoogleChrome/modern-web-guidance):** Terapkan API web modern resmi Google Chrome (HTML Popover API, CSS Anchor Positioning, View Transitions API, native dialogs, container queries, subgrid, dan performa CWV/INP optimal).
- **Precision Craft:** Tipografi Modular, Kerning Optik `-0.035em`, `text-wrap: balance` pada heading, panjang baris `65-75ch`.
- **Complete State Coverage:** `Default` -> `Hover` -> `Active` -> `Focus-Visible` -> `Disabled` -> `Loading`.

---

## 5. Standar Motion Division AI Kit & Animasi Fisika (Skills: `motion-ai-kit`, `motion`, `framer-motion`, `lenis`)
- **Motion Division AI Kit Standards (`motiondivision/ai-kit`):**
  - **Physics over Durations:** Wajib gunakan parameter fisika pegas nyata (`stiffness`, `damping`, `mass`) atau CSS `linear()` springs.
  - **Hardware Acceleration Only:** Animasi wajib hanya menginterpolasi `transform` dan `opacity` (hindari manipulasi `width`, `height`, `top`, `margin` secara berlebihan).
  - **MotionScore Checklist:** Dukungan penuh `@media (prefers-reduced-motion: reduce)`, interruptible transitions, dan staggered entry halus ($\le 50\text{ms}$).
- **Smooth Momentum Scrolling:** 60fps momentum scroll, lerp, dan sinkronisasi GSAP ticker.

---

## 6. Standar Computational Graph, Sains & Arsitektur Kode (Skills: `comfyui`, `graphify`, `managing-python-dependencies`, `science`)
- **ComfyUI Node-Graph Computational Architecture (`comfy-org/comfyui`):**
  - **Directed Acyclic Graph (DAG):** Pisahkan alur proses kompleks menjadi node mandiri dengan input-output terdefinisi jelas tanpa *hidden side-effects*.
  - **Deterministic Pipeline Execution:** Loader, Sampler/Transformer, Processor, dan Output Decoder terisolasi secara modular untuk kemudahan audit dan optimasi.
- **DeepMind Science Suite (`google-deepmind/science-skills` v1.2.0):** Terapkan standar resmi DeepMind untuk analisis struktur makromolekul protein (AlphaFold), anotasi varian genomik (AlphaGenome), cheminformatics (ChEMBL), dan literatur biomedis terverifikasi.
- **Graphify Knowledge Graph:** Analisis relasi arsitektur codebase, god nodes, dan GraphRAG JSON.
- **Python Environment Management:** Selalu gunakan virtual environment (`venv`).

---

## 7. Keamanan & Pencegahan Kehilangan Data (Skill: `accidental-data-loss-prevention`)
- **Stop & Verify:** Selalu minta konfirmasi eksplisit sebelum menjalankan perintah destruktif permanen.

---

## 8. Standar Keamanan Enterprise, Anti-Clone, Pen-Testing & DevSecOps (Skills: `strix`, `penetration-testing-with-strix`, `web-app-penetration-testing`, `api-security-testing`, `application-security-testing`, `ci-security-scanning-with-strix`, `find-security-vulnerabilities-in-code`, `fix-security-vulnerabilities-with-strix`, `managed-pentesting-with-strix`, `owasp-top-10-testing`, `secops-agent-kit`, `owasp-zap-security`)
- **Strix Autonomous AI Penetration Testing (`usestrix/strix` Full Suite):**
  - **PoC-First Vulnerability Verification:** Setiap temuan potensi celah keamanan (SQLi, XSS, CSRF, IDOR, SSRF, Broken Auth, Business Logic) wajib diverifikasi secara dinamis dengan Proof-of-Concept nyata sebelum dirilis untuk menjamin *zero false positives*.
  - **Comprehensive Multi-Vector Pentest:** Uji penetrasi web (`web-app-penetration-testing`), API (`api-security-testing`), CI security gate (`ci-security-scanning-with-strix`), dan OWASP Top 10 (`owasp-top-10-testing`).
  - **Attack Surface Fuzzing & Dynamic Sandbox:** Simulasi serangan injeksi dan payload tamper pada seluruh form dan API endpoint.
- **SecOpsAgentKit DevSecOps & Threat Modeling (`AgentSecOps/SecOpsAgentKit`):**
  - **Threat Modeling (STRIDE/PASTA):** Analisis ancaman arsitektur (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege).
  - **Zero-Secret Leakage (Gitleaks Standard):** Larangan mutlak menaruh kredensial privat / service role key di frontend.
  - **SAST & DAST Continuous Quality Gate:** Audit statis dan dinamis pada setiap perubahan kode.
- **Anti-Clickjacking & Anti-Clone Defense (Framebusting):**
  - Pasang header `X-Frame-Options: SAMEORIGIN`, CSP `frame-ancestors 'self'`, dan client-side framebusting breakout script untuk mencegah serangan kloning dan iframe phising.
- **Strict SQL Injection (SQLi) & NoSQL Prevention:**
  - Wajib menerapkan sanitasi ketat pada seluruh parameter input pengguna (`SecurityUtils.sanitizeInput`, stripping raw SQL comments `--`, `/*`, `;`, and single quotes). Gunakan parameterized queries / Supabase RPC binding tanpa penggabungan string raw SQL berbahaya.
- **XSS & DOM Injection Neutralization:**
  - Wajib menerapkan HTML Entity Encoding (`SecurityUtils.escapeHTML`) sebelum merender data dinamis ke DOM, dan sanitasi protokol URL (`SecurityUtils.sanitizeURL`) memblokir skema `javascript:`, `data:`, `vbscript:`.
- **Mandatory HTTP Security Headers (OWASP ZAP 100% Pass):**
  - `X-Frame-Options: SAMEORIGIN`
  - `X-Content-Type-Options: nosniff`
  - `X-XSS-Protection: 1; mode=block`
  - `Referrer-Policy: strict-origin-when-cross-origin`
  - `Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=()`
  - `Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: https: blob:; connect-src 'self' https://*.supabase.co; frame-ancestors 'self'; base-uri 'self'; form-action 'self';`
  - `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload` (pada HTTPS/Production).

---

## 9. Prinsip Bedah Presisi & Integritas Kode (Strict Surgical Execution & Non-Regression Gate)
- **Hanya Perbaiki yang Diminta (Scope Isolation & Minimal Working Diff):** AI hanya boleh memodifikasi bagian kode, baris, atau file yang secara spesifik diminta oleh pengguna atau menjadi akar masalah (root cause) dari issue yang dilaporkan.
- **Mutlak Dilarang Mengubah/Menghapus Kode Lain:** Dilarang keras merombak ulang arsitektur yang sudah stabil, menghapus fungsionalitas yang sudah bekerja (working features), atau menyentuh berkas yang tidak relevan tanpa instruksi eksplisit dari pengguna.
- **Zero Regression Quality Gate:** Setiap perbaikan wajib mempertahankan 100% fungsionalitas fitur yang sudah ada sebelumnya dan menjamin tidak ada efek samping (side-effects) baru pada modul lain.

---

## 10. Standar Auto-Persona Skill Orchestration: Riset Ilmiah, Akademik Indonesia, Humanizer & Chrome DevTools (Zero-Prompting Always-On)
Tanpa menunggu pengguna mengetik nama skill, aktifkan persona spesialis dan muat `SKILL.md` serta MCP terkait secara otomatis sesuai konteks tugas:
- **Riset & Publikasi Ilmiah Internasional (`paper-orchestra`, `academic-pipeline`, `deep-research`, `sr-screener`, `academic-paper`, `academic-paper-reviewer`):** Otomatis aktif pada tugas riset literatur, systematic review, penulisan paper ilmiah/LaTeX dari log eksperimen, plotting grafik publikasi, dan peer-review multi-perspektif.
- **Naskah Akademik Indonesia & Kompilasi Kampus (`naskah-id`, `menulis-cepat`, `laporan-generator` + MCP `laporan`):** Otomatis aktif pada penulisan, penyuntingan EYD V/KBBI, audit sitasi Crossref/OpenAlex (`scripts/openalex.py`, `scripts/periksa.py`), dan pembangunan skripsi/tesis/laporan PKL/makalah ke PDF (Typst) & DOCX (Pandoc/OpenXML) via MCP `laporan`. Klaim tanpa data wajib diberi penanda `[PERLU DATA: ...]` atau `[PERLU RUJUKAN: ...]`.
- **Prosa Manusiawi Bebas Pola Mesin (`humanizer` v4.0, `humanizer-indonesia`, `stop-slop`):** Otomatis menyaring seluruh 26+ pola tulisan AI (*staging*, *not-X-but-Y*, *dramatic closers*, *forced triads*, *em-dash*) pada setiap output tulisan tanpa mengubah fakta atau angka.
- **Modern Web Platform & Live Browser Debugging (`modern-web-guidance`, `web-baseline`, `chrome-extensions` + MCP `chrome-devtools-mcp` & 8 DevTools Skills):** Otomatis mengutamakan API Web Platform Baseline modern serta memanggil `chrome-devtools-mcp` (`chrome-devtools`, `a11y-debugging`, `debug-optimize-lcp`, `memory-leak-debugging`, `cookie-debugging`, `inspect-in-devtools`, `troubleshooting`) saat menginspeksi, menguji, dan mengoptimasi aplikasi web di Chrome.

