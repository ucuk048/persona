# Panduan Lengkap Command & Prompt AGY CLI (Antigravity CLI)

Dokumen ini berisi daftar lengkap semua perintah (slash commands), opsi terminal, dan prompt yang tersedia di Google Antigravity CLI (`agy`).

---

## 1. Slash Commands (Di dalam Sesi Interaktif AGY)

Ketik perintah berikut langsung pada bilah input chat:

### Mode Alur Kerja & Penalaran
* `/plan` — Masuk ke mode perencanaan langkah-demi-langkah yang terstruktur sebelum mengeksekusi perubahan kode.
* `/goal` — Mode berorientasi tujuan (*long-running goal*); agen terus bekerja, menguji, dan memverifikasi hingga tugas tuntas sepenuhnya tanpa berhenti di tengah jalan.
* `/boost` — Mengaktifkan penalaran mendalam (*deep thinking*, riset multi-perspektif, dan verifikasi ketat) untuk problem yang rumit.
* `/grill-me` — Wawancara interaktif di mana agen menguji asumsi dan menantang keputusan arsitektur/desain Anda agar rencana matang.
* `/teamwork-preview` — Menjalankan tim sub-agen otonom untuk menyelesaikan proyek besar secara paralel dan kolaboratif.
* `/schedule` — Mengatur timer satu kali (*one-shot*) atau pekerjaan berulang (*recurring cron job*).
* `/learn` — Menyimpan kebiasaan, preferensi, atau koreksi baru agar diingat oleh agen pada sesi-sesi selanjutnya.
* `/btw <pertanyaan>` — Mengajukan pertanyaan selingan cepat tanpa merusak alur atau membuang konteks percakapan utama.

### Pengelolaan Konteks & Riwayat Percakapan
* `/compact` — Mengompres dan meringkas konteks percakapan yang panjang agar membebaskan ruang *context window*.
* `/clear` — Membersihkan layar terminal dan mereset sesi aktif saat ini.
* `/undo` — Membatalkan aksi, perubahan kode, atau langkah terakhir yang dilakukan agen.
* `/summary` — Menampilkan ringkasan poin-poin penting yang telah dikerjakan selama sesi berlangsung.
* `/branch` — Membuat cabang (*fork*) sesi baru dari titik percakapan tertentu.
* `/history` — Melihat dan memilih daftar riwayat sesi percakapan sebelumnya.
* `/exit` atau `/quit` (atau `Ctrl+D Ctrl+D`) — Keluar dari sesi interaktif AGY CLI.

### Kode, Berkas & Git
* `/open <path>` — Membuka berkas di editor teks atau melihat daftar berkas yang telah dimodifikasi.
* `/diff` — Menampilkan perbedaan kode (*git diff*) dari seluruh perubahan yang dilakukan agen.
* `/review` — Membuka antarmuka interaktif untuk meninjau dan menyetujui/menolak perubahan berkas.
* `/commit` — Membantu menyusun pesan commit yang rapi dan melakukan commit git pada repository.

### Konfigurasi & Model
* `/model` — Melihat atau mengganti model AI yang aktif (misal: Gemini Flash, Gemini Pro, Claude, dll.).
* `/effort` — Mengatur tingkat penalaran (*reasoning effort*: `low`, `medium`, `high`, `xhigh`, `max`).
* `/config` (alias: `/settings`) — Membuka panel konfigurasi dan preferensi CLI.
* `/permissions` — Mengatur hak akses dan whitelist izin eksekusi tool (terminal, edit berkas, dsb.).
* `/agents` — Menampilkan daftar custom sub-agen yang tersedia.
* `/skills` — Menampilkan dan mengelola daftar skill yang aktif atau terpasang.
* `/plugin` — Mengelola ekosistem plugin (instal, hapus, aktifkan, atau nonaktifkan plugin).
* `/hooks` — Mengonfigurasi hook otomatis yang terpicu saat tool/peristiwa tertentu dijalankan.
* `/remote-control [on|off]` — Mengaktifkan/menonaktifkan antarmuka remote daemon.
* `/statusline` — Menyalakan atau mematikan bilah status (*statusline*) di bagian bawah terminal.
* `/title [on|off]` — Mengatur judul jendela terminal.

### Informasi & Kuota
* `/help` — Menampilkan menu bantuan internal dan daftar tombol pintas (*keybindings*).
* `/usage` (alias: `/quota`) — Melihat statistik penggunaan token dan kuota model AI.
* `/credits` — Memeriksa sisa kredit AI yang tersedia.
* `/changelog` — Menampilkan riwayat perubahan versi dan fitur terbaru AGY.

---

## 2. Subcommands Terminal Shell (`agy <subcommand>`)

Dijalankan langsung dari terminal Linux / Termux:

* `agy models` — Menampilkan daftar semua model AI yang dapat digunakan.
* `agy agents` — Menampilkan daftar custom agent yang terpasang.
* `agy mcp` — Mengelola konfigurasi server MCP (*Model Context Protocol*).
* `agy plugin` — Mengelola plugin AGY langsung dari command line.
* `agy remote-control` — Mengontrol daemon remote control (`start`, `status`, `stop`).
* `agy update` — Memperbarui binary `agy` ke versi rilis terbaru.
* `agy changelog` — Membaca catatan rilis terbaru di terminal.
* `agy install` — Mengonfigurasi path lingkungan dan integrasi shell.

---

## 3. Flag / Argumen Baris Perintah Populer

* `agy -c` atau `agy --continue` — Melanjutkan sesi percakapan terakhir.
* `agy --conversation <id>` — Membuka kembali sesi tertentu berdasarkan ID percakapan.
* `agy -p "<prompt>"` / `agy --print "<prompt>"` — Menjalankan satu prompt non-interaktif dan langsung mencetak hasilnya.
* `agy -i "<prompt>"` — Mengirimkan prompt awal dan langsung membuka sesi interaktif.
* `agy --mode <auto|plan|accept-edits>` — Menentukan mode eksekusi agen sejak awal.
* `agy --effort <low|medium|high|max>` — Menentukan tingkat penalaran awal.
* `agy --dangerously-skip-permissions` — Menjalankan semua aksi tool tanpa konfirmasi manual.
* `agy --add-dir <path>` — Menambahkan folder tambahan ke dalam workspace aktif.

---

## 4. Perintah Cepat Skill & Persona Inti (Core Shortcuts)

Dapat diketikkan langsung sebagai prompt perintah atau slash command:

* `/rtk` (atau `rtk gain`) — Menampilkan statistik efisiensi penghematan token keluaran shell.
* `/caveman` — Mengaktifkan mode bicara padat fakta tanpa basa-basi (`[Objek] [Tindakan] [Alasan]. [Langkah berikutnya].`).
* `/ponytail` — Menegakkan prinsip *Lazy Senior Dev* (YAGNI, codebase reuse, standard library first).
* `/security-audit` — Menjalankan audit kerentanan OWASP Top 10 berbasis *Cloudflare vulnerability discovery harness*.
* `/auto-fullstack` — Memulai orkestrator pipeline 9-fase perancangan aplikasi lengkap dari PRD hingga QA.
* `/genoffice` — Membuat atau menyunting dokumen Word (.docx), Excel (.xlsx), presentasi PowerPoint (.pptx), atau berkas PDF.
* `/humanizer-indonesia` — Menyusun tulisan berbahasa Indonesia bernada alami, bebas kalke, dan berpredikat *Turnitin-safe*.
* `/patterncraft` — Mengambil pustaka 150+ pattern latar belakang CSS/Tailwind zero-asset.
* `/transitions-dev` — Memanggil 32+ kelas transisi mikro-interaksi CSS (`t-*` classes).
* `/uiverse-ui` — Mengambil pustaka komponen interaktif taktil (glow buttons, animated checkboxes, floating inputs).
