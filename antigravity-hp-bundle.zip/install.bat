@echo off
echo ==========================================================
echo    ANTIGRAVITY (AGY) INSTALLER FOR WINDOWS (CMD)
echo ==========================================================
echo Menjalankan skrip PowerShell instalasi...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
