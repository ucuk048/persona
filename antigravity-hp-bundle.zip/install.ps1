# ==========================================================
#   ANTIGRAVITY (AGY) CONFIGURATION INSTALLER FOR WINDOWS
# ==========================================================

$ErrorActionPreference = "Stop"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   ANTIGRAVITY (AGY) CONFIGURATION INSTALLER (WINDOWS)" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$userProfile = [System.Environment]::GetFolderPath('UserProfile')
$targetDir = Join-Path $userProfile ".gemini"
$configDir = Join-Path $targetDir "config"
$cliDir = Join-Path $targetDir "antigravity-cli"
$skillsDir = Join-Path $configDir "skills"

Write-Host "[1/4] Membuat direktori target di $targetDir..." -ForegroundColor Yellow
if (-not (Test-Path $configDir)) { New-Item -ItemType Directory -Path $configDir -Force | Out-Null }
if (-not (Test-Path $cliDir)) { New-Item -ItemType Directory -Path $cliDir -Force | Out-Null }
if (-not (Test-Path $skillsDir)) { New-Item -ItemType Directory -Path $skillsDir -Force | Out-Null }

Write-Host "[2/4] Menyalin 85 Skills & Skills Index..." -ForegroundColor Yellow
Copy-Item -Path "config\skills\*" -Destination $skillsDir -Recurse -Force
Copy-Item -Path "config\skills.json" -Destination (Join-Path $configDir "skills.json") -Force

Write-Host "[3/4] Memasang Rules & Personas (GEMINI.md)..." -ForegroundColor Yellow
Copy-Item -Path "config\GEMINI.md" -Destination (Join-Path $configDir "GEMINI.md") -Force

Write-Host "[4/4] Mengonfigurasi Settings & Always-Allow Permissions..." -ForegroundColor Yellow
$settingsPath = Join-Path $cliDir "settings.json"
if (Test-Path $settingsPath) {
    Copy-Item -Path $settingsPath -Destination (Join-Path $cliDir "settings.json.bak") -Force
}

$escapedUserProfile = $userProfile.Replace("\", "/")
$settingsContent = @"
{
  "agentMode": "accept-edits",
  "allowNonWorkspaceAccess": true,
  "artifactReviewPolicy": "always-proceed",
  "model": "Gemini 3.8 Flash (High)",
  "notifications": true,
  "permissions": {
    "allow": [
      "*",
      "command(*)",
      "read_file(*)",
      "write_file(*)",
      "edit_file(*)",
      "search_web(*)",
      "manage_task(*)",
      "manage_subagents(*)",
      "invoke_subagent(*)",
      "schedule(*)"
    ]
  },
  "runningLightSpeed": "fast",
  "toolPermission": "always-proceed",
  "trustedWorkspaces": [
    "$escapedUserProfile"
  ],
  "useG1Credits": true,
  "verbosity": "high"
}
"@

[System.IO.File]::WriteAllText($settingsPath, $settingsContent, [System.Text.Encoding]::UTF8)

Write-Host ""
Write-Host "==========================================================" -ForegroundColor Green
Write-Host " [SUCCESS] Seluruh 85 skills, rules & settings berhasil" -ForegroundColor Green
Write-Host "           terpasang di laptop Windows Anda!" -ForegroundColor Green
Write-Host " Direktori Config: $configDir" -ForegroundColor Green
Write-Host " Direktori Settings: $settingsPath" -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Green
