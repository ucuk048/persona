#!/usr/bin/env python3
"""
Antigravity & Hermes Universal Skills Updater
Memperbarui seluruh skill dari repositori Git hulu, menyinkronkan ke HP, 
dan memperbarui paket bundle Laptop serta Hermes secara otomatis.
"""

import os
import subprocess
import json
import zipfile

BASE_DIR = "/sdcard/Antigravity"
CUSTOM_SRC = os.path.join(BASE_DIR, "customizations_src")
HP_SKILLS_GLOBAL = os.path.expanduser("~/.gemini/config/skills")
HP_SKILLS_LOCAL = os.path.join(BASE_DIR, ".agents/skills")
LAPTOP_SKILLS = os.path.join(BASE_DIR, "laptop_bundle/config/skills")
HERMES_SKILLS = os.path.join(BASE_DIR, "hermes_bundle/skills")

def run_cmd(cmd, cwd=None):
    try:
        res = subprocess.run(cmd, cwd=cwd, shell=True, capture_output=True, text=True, check=True)
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        return f"Error: {e.stderr.strip()}"

def update_git_repos():
    print("=== [1/4] Memeriksa & Mengunduh Update Repositori Git ===")
    if not os.path.exists(CUSTOM_SRC):
        print("Direktori customizations_src tidak ditemukan.")
        return

    repos = [d for d in os.listdir(CUSTOM_SRC) if os.path.isdir(os.path.join(CUSTOM_SRC, d))]
    for repo in sorted(repos):
        repo_path = os.path.join(CUSTOM_SRC, repo)
        git_dir = os.path.join(repo_path, ".git")
        if os.path.exists(git_dir):
            out = run_cmd("git pull --rebase", cwd=repo_path)
            last_line = out.splitlines()[-1] if out else "OK"
            print(f"  - {repo}: {last_line}")

def sync_skills():
    print("\n=== [2/4] Menyinkronkan Berkas Skills ke Sistem ===")
    count = 0
    for root, dirs, files in os.walk(CUSTOM_SRC):
        # Prune heavy non-skill dirs
        dirs[:] = [d for d in dirs if d not in [".git", "node_modules", "dist", "build", "vendor", "packaging"]]
        if "SKILL.md" in files:
            skill_name = os.path.basename(root)
            if skill_name == "skills":
                continue
            src_skill_md = os.path.join(root, "SKILL.md")
            
            targets = [
                os.path.join(HP_SKILLS_GLOBAL, skill_name),
                os.path.join(HP_SKILLS_LOCAL, skill_name),
                os.path.join(LAPTOP_SKILLS, skill_name),
                os.path.join(HERMES_SKILLS, skill_name)
            ]
            
            with open(src_skill_md, "r", encoding="utf-8", errors="ignore") as f_in:
                raw_content = f_in.read()
            
            for t in targets:
                os.makedirs(t, exist_ok=True)
                dest_file = os.path.join(t, "SKILL.md")
                content = raw_content
                if "laptop" in t or "hermes" in t:
                    content = content.replace("/sdcard/Antigravity/<nama-proyek>/", "<workspace>/<nama-proyek>/")
                    content = content.replace("/sdcard/Antigravity/", "<workspace>/")
                    content = content.replace("/sdcard", "<workspace>")
                with open(dest_file, "w", encoding="utf-8") as f_out:
                    f_out.write(content)
            count += 1

    print(f"Sinkronisasi selesai ({count} skills dari repositori hulu terupdate).")

def update_indexes():
    print("\n=== [3/4] Memperbarui Index JSON & Status ===")
    all_skills = sorted(os.listdir(HP_SKILLS_GLOBAL))
    data = {
        "version": "1.0",
        "updated_at": "auto-updater",
        "total_skills": len(all_skills),
        "skills": all_skills
    }
    
    for json_p in [
        os.path.expanduser("~/.gemini/config/skills.json"),
        os.path.join(BASE_DIR, ".agents/skills.json"),
        os.path.join(BASE_DIR, "laptop_bundle/config/skills.json")
    ]:
        with open(json_p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            
    print(f"Total skills aktif terindeks: {len(all_skills)}")

def make_zip(src_dir, zip_path):
    if os.path.exists(zip_path):
        os.remove(zip_path)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(src_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, src_dir)
                zipf.write(full_path, rel_path)
    size_kb = os.path.getsize(zip_path) / 1024
    print(f"  - {os.path.basename(zip_path)}: {size_kb:.1f} KB")

def rebuild_bundles():
    print("\n=== [4/4] Membangun Ulang Paket Bundle Laptop & Hermes ===")
    hp_staging = os.path.join(BASE_DIR, "hp_bundle")
    os.system(f"cp -r {HP_SKILLS_GLOBAL} {hp_staging}/config/")
    os.system(f"cp {os.path.expanduser('~/.gemini/config/skills.json')} {hp_staging}/config/")
    os.system(f"cp {os.path.expanduser('~/.gemini/config/GEMINI.md')} {hp_staging}/config/")
    os.system(f"cp {os.path.join(BASE_DIR, 'terpasang.txt')} {hp_staging}/")
    
    make_zip(hp_staging, os.path.join(BASE_DIR, "antigravity-hp-bundle.zip"))
    make_zip(os.path.join(BASE_DIR, "laptop_bundle"), os.path.join(BASE_DIR, "antigravity-laptop-bundle.zip"))
    make_zip(os.path.join(BASE_DIR, "hermes_bundle"), os.path.join(BASE_DIR, "antigravity-hermes-bundle.zip"))

def main():
    print("==================================================")
    print("   UNIVERSAL SKILLS UPDATER (HP / LAPTOP / HERMES)")
    print("==================================================")
    update_git_repos()
    sync_skills()
    update_indexes()
    rebuild_bundles()
    print("\n[SELESAI] Seluruh skill berhasil diperbarui dan disinkronkan!")

if __name__ == "__main__":
    main()
