# PANDUAN INSTALASI KONFIGURASI ANTIGRAVITY PADA LAPTOP

Paket bundle ini berisi seluruh konfigurasi lengkap dari HP/Termux:
- **503 Skills Aktif**: Full-Stack Orchestrator, Modern UI/UX Suite (PatternCraft, Transitions.dev, Uiverse, Taste, Hallmark, UUPM, Craftwork, Ryux), GameDev Engine Suite (Godot, Unity, Unreal, Phaser, Three.js, Bevy, dll), Backend, DevOps, Cloudflare Security Audit, Ponytail, Caveman, RTK Token Killer, GenOffice, Academic Suite, dll.
- **Rules & Personas**: `GEMINI.md` (termasuk protokol otomatisasi PRD, Inception, dan Pipeline 9-Fase).
- **Settings & Permissions**: `settings.json` dengan izin `always-allow` (`permissions: ["*"]` dan `toolPermission: "always-proceed"`).

---

## Cara Mentransfer ke Laptop

Anda dapat memindahkan berkas `antigravity-laptop-bundle.zip` ke laptop menggunakan salah satu cara berikut:
1. **Kabel USB**: Hubungkan HP ke laptop via USB, buka penyimpanan internal, lalu salin berkas `antigravity-laptop-bundle.zip` yang ada di folder `Antigravity/`.
2. **LocalSend / Quick Share / Bluetooth**: Kirim langsung dari pengelola file HP ke laptop.
3. **Web Server Termux Instan (Wi-Fi Lokal)**:
   Di Termux, jalankan perintah:
   ```bash
   python3 -m http.server 8080 --directory /sdcard/Antigravity
   ```
   Lalu buka browser di laptop dan ketik: `http://<IP-HP-ANDA>:8080` dan klik `antigravity-laptop-bundle.zip` untuk mengunduhnya.

---

## Cara Instalasi di Laptop

Ekstrak berkas `antigravity-laptop-bundle.zip` di laptop Anda, lalu ikuti instruksi sesuai sistem operasi:

### A. Untuk Pengguna Windows
1. Buka folder hasil ekstrak.
2. Klik kanan pada berkas `install.bat` dan pilih **Run as administrator** (atau klik dua kali).
   * Atau buka **PowerShell** di folder tersebut, lalu jalankan:
     ```powershell
     .\install.ps1
     ```
3. Selesai! Konfigurasi akan otomatis terpasang di `C:\Users\<Username>\.gemini\`.

---

### B. Untuk Pengguna macOS / Linux / WSL
1. Buka terminal di dalam folder hasil ekstrak.
2. Berikan izin eksekusi dan jalankan `install.sh`:
   ```bash
   chmod +x install.sh
   ./install.sh
   ```
3. Selesai! Konfigurasi akan otomatis terpasang di `~/.gemini/`.

---

## Verifikasi di Laptop
Setelah menjalankan installer, buka terminal di laptop Anda dan jalankan Antigravity CLI:
```bash
agy
```
Ketik perintah:
```
/skills
```
Anda akan melihat seluruh 503 skills terdeteksi aktif, mode permissions berstatus `always-allow`, dan alur kerja auto-fullstack siap digunakan!
