#!/usr/bin/env python3
"""
=============================================================================
AUTO BACKUP TOOL: ZIP + GITHUB + GOOGLE DRIVE
=============================================================================
Script otomatis untuk mencadangkan (backup) folder ke file ZIP lalu mengunggahnya
ke GitHub Releases dan Google Drive.

FITUR UTAMA:
1. Auto-Detection: Otomatis mendeteksi folder tempat script ini disimpan.
   Contoh: simpan di folder 'SKRIPSI', jalankan 'python3 auto_backup.py',
   maka seluruh isi folder 'SKRIPSI' otomatis di-zip dan di-upload.
2. Smart Exclusion: Mengabaikan script ini sendiri, file config/token (.env/json),
   file ZIP sebelumnya, git metadata (.git), temp/lock file Word (~$*), dan cache.
3. Dual Upload:
   - GitHub: Otomatis membuat GitHub Release dan upload aset ZIP (kapasitas s/d 2GB).
   - Google Drive: Otomatis upload via OAuth2 REST API (atau Rclone) ke folder Drive.
4. Flexible Config: Mendukung konfigurasi global (~/.backup_config.json) atau
   lokal (backup_config.json di folder target).
5. Zero Dependencies: Berjalan murni menggunakan Python Standard Library (3.7+).
=============================================================================
"""

import os
import sys
import json
import time
import shutil
import zipfile
import fnmatch
import argparse
import subprocess
import urllib.request
import urllib.parse
import urllib.error
from pathlib import Path
from datetime import datetime

# Versi Tool
VERSION = "1.0.0"

# Lokasi default config
GLOBAL_CONFIG_PATH = Path.home() / ".backup_config.json"
LOCAL_CONFIG_NAME = "backup_config.json"

# Pola file/folder yang dikecualikan dari ZIP
DEFAULT_EXCLUDES = [
    "*.zip",
    "*.tar",
    "*.tar.gz",
    "*.tgz",
    "*.rar",
    "*.7z",
    "~$*",               # File lock Microsoft Office (Word, Excel, PowerPoint)
    "*.tmp",
    "*.temp",
    "*.swp",
    "*.bak",
    ".git",
    ".git/*",
    ".github",
    ".github/*",
    ".gitignore",
    ".gitattributes",
    "__pycache__",
    "__pycache__/*",
    "*.pyc",
    "node_modules",
    "node_modules/*",
    ".venv",
    ".venv/*",
    "venv",
    "venv/*",
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
    "backup_config.json",
    ".backup_config.json",
    ".env",
    ".env.*",
]


# ============================================================================
# HELPER FUNCTIONS & FORMATTING
# ============================================================================

def format_size(bytes_size):
    """Konversi byte ke format satuan yang mudah dibaca manusia."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024.0
    return f"{bytes_size:.2f} PB"


def log(prefix, message, color=None):
    """Tampilkan log dengan penanda terstruktur."""
    timestamp = datetime.now().strftime("%H:%M:%S")
    symbols = {
        "INFO": "[\033[94mINFO\033[0m]",
        "SUCCESS": "[\033[92mOK\033[0m]",
        "WARN": "[\033[93mWARN\033[0m]",
        "ERROR": "[\033[91mERR\033[0m]",
        "ZIP": "[\033[96mZIP\033[0m]",
        "LOCAL": "[\033[93mLOCAL\033[0m]",
        "GITHUB": "[\033[95mGITHUB\033[0m]",
        "GDRIVE": "[\033[92mGDRIVE\033[0m]",
    }
    sym = symbols.get(prefix, f"[{prefix}]")
    print(f"{sym} {message}")


def should_exclude(rel_path, filename, custom_excludes=None):
    """Periksa apakah berkas/folder harus diabaikan dari arsip ZIP."""
    # Selalu abaikan script ini sendiri (baik nama auto_backup.py atau nama file saat dieksekusi)
    if filename == Path(__file__).name or filename == "auto_backup.py":
        return True

    # Abaikan file lock Office Word/Excel (~$*.docx, ~.docx, dll)
    if filename.startswith("~$") or filename.startswith(".~lock.") or filename.startswith("~"):
        return True

    excludes = list(DEFAULT_EXCLUDES)
    if custom_excludes:
        excludes.extend(custom_excludes)

    parts = rel_path.split(os.sep)
    for p in parts:
        if p in [".git", "__pycache__", "node_modules", ".venv", "venv"]:
            return True

    for pattern in excludes:
        if fnmatch.fnmatch(filename, pattern) or fnmatch.fnmatch(rel_path, pattern):
            return True
    return False


# ============================================================================
# CONFIGURATION MANAGEMENT
# ============================================================================

def find_config(target_dir):
    """Cari file konfigurasi lokal terlebih dahulu, lalu global."""
    local_cfg = target_dir / LOCAL_CONFIG_NAME
    if local_cfg.is_file():
        return local_cfg, "lokal"

    if GLOBAL_CONFIG_PATH.is_file():
        return GLOBAL_CONFIG_PATH, "global"

    return None, None


def load_config(target_dir):
    """Muat konfigurasi dari file JSON."""
    cfg_path, scope = find_config(target_dir)
    if not cfg_path:
        return None, None

    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data, cfg_path
    except Exception as e:
        log("ERROR", f"Gagal membaca konfigurasi dari {cfg_path}: {e}")
        return None, None


def get_default_config_template():
    """Template default konfigurasi backup."""
    return {
        "github": {
            "enabled": True,
            "repo": "username/nama-repo-backup",
            "token": "ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            "method": "auto"  # 'auto', 'api', atau 'gh_cli'
        },
        "gdrive": {
            "enabled": True,
            "method": "oauth",  # 'oauth' atau 'rclone'
            "client_id": "xxxxxxxxxxxx.apps.googleusercontent.com",
            "client_secret": "GOCSPX-xxxxxxxxxxxxxxxxxxxx",
            "refresh_token": "1//xxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            "folder_id": "",    # ID folder Google Drive tujuan (opsional)
            "rclone_remote": "gdrive" # jika menggunakan method 'rclone'
        },
        "local_drives": {
            "enabled": True,
            "paths": [
                "E:/Backup",
                "F:/Backup"
            ]
        },
        "options": {
            "keep_local_zip": True,
            "custom_excludes": []
        }
    }


def save_config(config_data, path):
    """Simpan data konfigurasi ke berkas JSON dengan indentasi rapi."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(config_data, f, indent=2, ensure_ascii=False)
    log("SUCCESS", f"Konfigurasi berhasil disimpan di: {path}")


# ============================================================================
# COMPRESSION / ZIP CREATOR
# ============================================================================

def create_backup_zip(target_dir, custom_excludes=None):
    """Kompres seluruh isi folder target ke dalam satu file ZIP."""
    folder_name = target_dir.name
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"{folder_name}_backup_{timestamp}.zip"
    zip_filepath = target_dir / zip_filename

    log("ZIP", f"Mendeteksi folder target: \033[1m{target_dir}\033[0m")
    log("ZIP", f"Memulai kompresi ke: \033[1m{zip_filename}\033[0m")

    files_to_zip = []
    total_uncompressed_bytes = 0

    for root, dirs, files in os.walk(target_dir):
        # Modifikasi dirs in-place agar os.walk tidak masuk ke folder terabaikan
        dirs[:] = [d for d in dirs if not should_exclude(str((Path(root) / d).relative_to(target_dir)), d, custom_excludes)]

        for file in files:
            full_path = Path(root) / file
            rel_path = full_path.relative_to(target_dir)
            rel_str = str(rel_path)

            if should_exclude(rel_str, file, custom_excludes):
                continue

            try:
                size = full_path.stat().st_size
                files_to_zip.append((full_path, rel_str))
                total_uncompressed_bytes += size
            except OSError:
                continue

    if not files_to_zip:
        log("WARN", "Tidak ada berkas yang ditemukan untuk dicadangkan.")
        return None

    log("ZIP", f"Mengompres {len(files_to_zip)} berkas ({format_size(total_uncompressed_bytes)})...")

    start_time = time.time()
    with zipfile.ZipFile(zip_filepath, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
        for full_p, rel_p in files_to_zip:
            zipf.write(full_p, arcname=rel_p)

    elapsed = time.time() - start_time
    compressed_bytes = zip_filepath.stat().st_size
    ratio = (1.0 - (compressed_bytes / total_uncompressed_bytes)) * 100 if total_uncompressed_bytes > 0 else 0

    log("SUCCESS", f"ZIP selesai dibuat dalam {elapsed:.2f} detik.")
    log("INFO", f"Ukuran: {format_size(compressed_bytes)} (Hemat {ratio:.1f}% dari {format_size(total_uncompressed_bytes)})")
    return zip_filepath


# ============================================================================
# GITHUB UPLOADER (API & CLI)
# ============================================================================

def upload_to_github_via_api(repo, token, zip_path, folder_name):
    """Unggah file ZIP sebagai asset release menggunakan GitHub REST API."""
    repo = repo.strip().strip("/")
    tag_name = f"backup-{folder_name.lower()}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    release_title = f"Backup {folder_name} ({datetime.now().strftime('%d %b %Y, %H:%M')})"
    release_notes = (
        f"Automated backup of folder **{folder_name}**\n"
        f"- File: `{zip_path.name}`\n"
        f"- Size: `{format_size(zip_path.stat().st_size)}`\n"
        f"- Generated on: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
    )

    # 1. Buat Release baru
    release_url = f"https://api.github.com/repos/{repo}/releases"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "Antigravity-Auto-Backup"
    }
    payload = {
        "tag_name": tag_name,
        "name": release_title,
        "body": release_notes,
        "draft": False,
        "prerelease": False
    }

    log("GITHUB", f"Membuat Release di GitHub ({repo})...")
    req = urllib.request.Request(
        release_url,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST"
    )

    try:
        with urllib.request.urlopen(req) as resp:
            release_data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        err_msg = e.read().decode("utf-8", errors="ignore")
        log("ERROR", f"Gagal membuat release di GitHub (HTTP {e.code}): {err_msg}")
        return False
    except Exception as e:
        log("ERROR", f"Koneksi GitHub gagal: {e}")
        return False

    upload_url_template = release_data.get("upload_url", "")
    html_url = release_data.get("html_url", "")
    upload_url = upload_url_template.split("{")[0] + f"?name={urllib.parse.quote(zip_path.name)}"

    # 2. Upload file ZIP ke Release Asset
    log("GITHUB", f"Mengunggah berkas {zip_path.name} ({format_size(zip_path.stat().st_size)})...")
    file_size = zip_path.stat().st_size

    upload_headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/zip",
        "Content-Length": str(file_size),
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "Antigravity-Auto-Backup"
    }

    try:
        with open(zip_path, "rb") as f:
            upload_req = urllib.request.Request(upload_url, data=f, headers=upload_headers, method="POST")
            with urllib.request.urlopen(upload_req) as upload_resp:
                asset_data = json.loads(upload_resp.read().decode("utf-8"))
                download_url = asset_data.get("browser_download_url", "")
                log("SUCCESS", f"Upload ke GitHub Berhasil!")
                log("INFO", f"Release URL : {html_url}")
                log("INFO", f"Download URL: {download_url}")
                return True
    except urllib.error.HTTPError as e:
        err_msg = e.read().decode("utf-8", errors="ignore")
        log("ERROR", f"Gagal upload asset ke GitHub (HTTP {e.code}): {err_msg}")
        return False
    except Exception as e:
        log("ERROR", f"Gagal mengunggah asset ke GitHub: {e}")
        return False


def upload_to_github_via_cli(repo, zip_path, folder_name):
    """Unggah menggunakan GitHub CLI (gh release create)."""
    if not shutil.which("gh"):
        log("ERROR", "Perintah 'gh' tidak ditemukan di sistem.")
        return False

    tag_name = f"backup-{folder_name.lower()}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    title = f"Backup {folder_name} ({datetime.now().strftime('%d %b %Y, %H:%M')})"
    notes = f"Auto-backup of {folder_name} ({format_size(zip_path.stat().st_size)})"

    cmd = [
        "gh", "release", "create", tag_name,
        str(zip_path),
        "--repo", repo,
        "--title", title,
        "--notes", notes
    ]

    log("GITHUB", f"Menjalankan GitHub CLI ({repo})...")
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode == 0:
        url = res.stdout.strip()
        log("SUCCESS", f"Upload ke GitHub via CLI Berhasil!")
        log("INFO", f"Release URL: {url}")
        return True
    else:
        log("ERROR", f"GitHub CLI gagal: {res.stderr.strip()}")
        return False


def upload_to_github(config, zip_path, folder_name):
    """Dispatcher upload GitHub berdasarkan konfigurasi."""
    gh_cfg = config.get("github", {})
    if not gh_cfg.get("enabled", True):
        log("INFO", "Upload GitHub dinonaktifkan dalam konfigurasi.")
        return True

    repo = gh_cfg.get("repo", "").strip()
    token = gh_cfg.get("token", "").strip()
    method = gh_cfg.get("method", "auto")

    if not repo or repo == "username/nama-repo-backup":
        log("WARN", "Nama repository GitHub belum disetting dengan benar. Melewati upload GitHub.")
        return False

    # Deteksi metode
    if method == "gh_cli" or (method == "auto" and (not token or token.startswith("ghp_xxx"))):
        # Coba lewat gh CLI
        if shutil.which("gh"):
            return upload_to_github_via_cli(repo, zip_path, folder_name)
        else:
            log("ERROR", "Token GitHub belum diisi dan tool 'gh' tidak tersedia.")
            return False
    else:
        # Gunakan GitHub REST API langsung
        return upload_to_api_or_fallback(repo, token, zip_path, folder_name)


def upload_to_api_or_fallback(repo, token, zip_path, folder_name):
    """Coba API dulu; jika gagal dan gh cli ada, tawarkan/fallback."""
    success = upload_to_github_via_api(repo, token, zip_path, folder_name)
    if not success and shutil.which("gh"):
        log("WARN", "Mencoba fallback menggunakan GitHub CLI...")
        return upload_to_github_via_cli(repo, zip_path, folder_name)
    return success


# ============================================================================
# GOOGLE DRIVE UPLOADER (OAUTH REST & RCLONE)
# ============================================================================

def get_gdrive_access_token(client_id, client_secret, refresh_token):
    """Dapatkan access token baru menggunakan refresh token Google OAuth2."""
    url = "https://oauth2.googleapis.com/token"
    payload = urllib.parse.urlencode({
        "client_id": client_id,
        "client_secret": client_secret,
        "refresh_token": refresh_token,
        "grant_type": "refresh_token",
    }).encode("utf-8")

    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("access_token")
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="ignore")
        log("ERROR", f"Gagal memperbarui access token Google Drive: {err}")
        return None
    except Exception as e:
        log("ERROR", f"Koneksi Google OAuth gagal: {e}")
        return None


def upload_to_gdrive_oauth(client_id, client_secret, refresh_token, zip_path, folder_id=None):
    """Upload file ke Google Drive menggunakan Resumable Upload API v3."""
    log("GDRIVE", "Memperbarui token otorisasi Google Drive...")
    access_token = get_gdrive_access_token(client_id, client_secret, refresh_token)
    if not access_token:
        return False

    file_size = zip_path.stat().st_size
    file_name = zip_path.name

    # 1. Inisiasi Resumable Upload Session
    init_url = "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable"
    metadata = {"name": file_name}
    if folder_id and folder_id.strip():
        metadata["parents"] = [folder_id.strip()]

    init_headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json; charset=UTF-8",
        "X-Upload-Content-Type": "application/zip",
        "X-Upload-Content-Length": str(file_size),
    }

    log("GDRIVE", f"Menginisiasi sesi upload resumable ke Google Drive...")
    init_req = urllib.request.Request(
        init_url,
        data=json.dumps(metadata).encode("utf-8"),
        headers=init_headers,
        method="POST"
    )

    try:
        with urllib.request.urlopen(init_req) as resp:
            upload_session_url = resp.headers.get("Location")
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="ignore")
        log("ERROR", f"Gagal inisiasi upload Google Drive (HTTP {e.code}): {err}")
        return False
    except Exception as e:
        log("ERROR", f"Koneksi Google Drive gagal: {e}")
        return False

    if not upload_session_url:
        log("ERROR", "URL sesi upload Google Drive tidak diterima.")
        return False

    # 2. Upload Stream File
    log("GDRIVE", f"Mengunggah {file_name} ({format_size(file_size)})...")
    upload_headers = {
        "Content-Length": str(file_size),
        "Content-Type": "application/zip",
    }

    try:
        with open(zip_path, "rb") as f:
            upload_req = urllib.request.Request(
                upload_session_url,
                data=f,
                headers=upload_headers,
                method="PUT"
            )
            with urllib.request.urlopen(upload_req) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                file_id = result.get("id")
                web_link = f"https://drive.google.com/file/d/{file_id}/view"
                log("SUCCESS", "Upload ke Google Drive Berhasil!")
                log("INFO", f"File ID  : {file_id}")
                log("INFO", f"Drive URL: {web_link}")
                return True
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="ignore")
        log("ERROR", f"Gagal upload stream ke Google Drive (HTTP {e.code}): {err}")
        return False
    except Exception as e:
        log("ERROR", f"Gagal saat streaming upload Google Drive: {e}")
        return False


def upload_to_gdrive_rclone(remote_name, zip_path, folder_id=None):
    """Unggah file menggunakan tool Rclone."""
    if not shutil.which("rclone"):
        log("ERROR", "Tool 'rclone' tidak terpasang di sistem. Pasang via 'pkg install rclone'.")
        return False

    destination = f"{remote_name}:{folder_id.strip() if folder_id else 'Backup'}/{zip_path.name}"
    cmd = ["rclone", "copyto", str(zip_path), destination, "-P"]

    log("GDRIVE", f"Menjalankan rclone copyto ke {destination}...")
    res = subprocess.run(cmd)
    if res.returncode == 0:
        log("SUCCESS", "Upload via rclone berhasil!")
        return True
    else:
        log("ERROR", f"rclone gagal dengan kode keluar {res.returncode}")
        return False


def upload_to_gdrive(config, zip_path):
    """Dispatcher upload Google Drive berdasarkan konfigurasi."""
    gd_cfg = config.get("gdrive", {})
    if not gd_cfg.get("enabled", True):
        log("INFO", "Upload Google Drive dinonaktifkan dalam konfigurasi.")
        return True

    method = gd_cfg.get("method", "oauth")
    folder_id = gd_cfg.get("folder_id", "")

    if method == "rclone":
        remote_name = gd_cfg.get("rclone_remote", "gdrive")
        return upload_to_gdrive_rclone(remote_name, zip_path, folder_id)

    # Method OAuth
    client_id = gd_cfg.get("client_id", "").strip()
    client_secret = gd_cfg.get("client_secret", "").strip()
    refresh_token = gd_cfg.get("refresh_token", "").strip()

    if not client_id or not client_secret or not refresh_token or client_id.startswith("xxxx"):
        log("WARN", "Kredensial Google Drive belum diisi lengkap. Jalankan: python3 auto_backup.py --setup-gdrive")
        return False

    return upload_to_gdrive_oauth(client_id, client_secret, refresh_token, zip_path, folder_id)


# ============================================================================
# LOCAL DRIVES COPIER (DATA E & DATA F)
# ============================================================================

def copy_to_local_drives(config, zip_path, folder_name, cli_override_paths=None, skip_local=False):
    """
    Salin file ZIP cadangan ke drive lokal tambahan (misal: Data E: dan Data F:).
    Mendukung format Windows (E:/Backup, F:/Backup) serta Linux/WSL/Android (/mnt/e, /mnt/f, /sdcard/...).
    """
    if skip_local:
        log("INFO", "Penyalinan ke drive lokal dilewati (--no-local).")
        return []

    local_cfg = config.get("local_drives", {})
    if not local_cfg.get("enabled", True) and not cli_override_paths:
        log("INFO", "Penyalinan ke drive lokal dinonaktifkan dalam konfigurasi.")
        return []

    target_paths = cli_override_paths or local_cfg.get("paths", ["E:/Backup", "F:/Backup"])
    if isinstance(target_paths, str):
        target_paths = [target_paths]

    results = []

    print("\n" + "-"*70)
    print("  MEMULAI PENYALINAN KE DRIVE LOKAL (DATA E & F)")
    print("-" * 70)

    for raw_path in target_paths:
        raw_path = str(raw_path).strip()
        if not raw_path:
            continue

        resolved_dir = None
        drive_name = raw_path

        # 1. Kasus sistem Windows murni (win32)
        if sys.platform == "win32":
            if len(raw_path) >= 2 and raw_path[1] == ":":
                drive_letter = raw_path[0].upper()
                drive_root = Path(f"{drive_letter}:/")
                drive_name = f"Drive {drive_letter}:"
                if not drive_root.exists():
                    log("WARN", f"{drive_name} tidak terdeteksi atau belum terpasang. Melewati: {raw_path}")
                    results.append((raw_path, False, "Drive fisik belum terpasang"))
                    continue
            resolved_dir = Path(raw_path)

        # 2. Kasus sistem Linux / WSL / Android Termux
        else:
            if len(raw_path) >= 2 and raw_path[1] == ":":
                # Path format Windows seperti E:/Backup atau F:\Backup
                drive_letter = raw_path[0].lower()
                drive_name = f"Drive {drive_letter.upper()}:"
                # Bersihkan backslash dan drive letter
                subpath = raw_path[2:].replace("\\", "/").strip("/")
                wsl_root = Path(f"/mnt/{drive_letter}")

                if wsl_root.exists():
                    resolved_dir = wsl_root / subpath if subpath else wsl_root
                else:
                    # Bukan di WSL atau drive /mnt/<letter> tidak termount
                    log("WARN", f"{drive_name} ({raw_path}) tidak ditemukan di /mnt/{drive_letter}. Melewati.")
                    results.append((raw_path, False, f"Drive /mnt/{drive_letter} tidak terpasang"))
                    continue
            else:
                # Path Linux/Android biasa (contoh: /sdcard/Data_E atau /storage/xxxx)
                resolved_dir = Path(raw_path)

        try:
            resolved_dir.mkdir(parents=True, exist_ok=True)
            dest_file = resolved_dir / zip_path.name
            log("LOCAL", f"Menyalin ke {drive_name} ({dest_file})...")
            shutil.copy2(zip_path, dest_file)
            log("SUCCESS", f"Berhasil disalin ke: {dest_file}")
            results.append((raw_path, True, str(dest_file)))
        except Exception as e:
            log("ERROR", f"Gagal menyalin ke {raw_path}: {e}")
            results.append((raw_path, False, str(e)))

    return results


# ============================================================================
# INTERACTIVE SETUP & GOOGLE OAUTH HELPER
# ============================================================================

def setup_gdrive_oauth():
    """Wizard otomatis untuk mendapatkan Google Drive Refresh Token via browser callback."""
    import http.server

    print("\n" + "="*70)
    print("  GOOGLE DRIVE OAUTH SETUP WIZARD")
    print("="*70)
    print("Langkah cepat menyiapkan Google Drive API:")
    print("1. Kunjungi Google Cloud Console (https://console.cloud.google.com)")
    print("2. Buat Project baru (misal: 'Backup-Pribadi')")
    print("3. Aktifkan 'Google Drive API' di menu APIs & Services > Library")
    print("4. Masuk ke 'OAuth consent screen', pilih External/Testing, tambahkan email Anda.")
    print("5. Masuk ke 'Credentials' > 'Create Credentials' > 'OAuth client ID':")
    print("   - Application type: Web application (atau Desktop app)")
    print("   - Authorized redirect URIs: http://localhost:8085")
    print("="*70 + "\n")

    client_id = input("Masukkan Google Client ID: ").strip()
    if not client_id:
        print("Batal: Client ID kosong.")
        return

    client_secret = input("Masukkan Google Client Secret: ").strip()
    if not client_secret:
        print("Batal: Client Secret kosong.")
        return

    redirect_uri = "http://localhost:8085"
    scope = "https://www.googleapis.com/auth/drive.file"

    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": scope,
        "access_type": "offline",
        "prompt": "consent"
    }
    auth_url = f"https://accounts.google.com/o/oauth2/v2/auth?{urllib.parse.urlencode(params)}"

    auth_code_container = {"code": None}

    class OAuthHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            if "code" in query:
                auth_code_container["code"] = query["code"][0]
                self.send_response(200)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                html = """
                <html><body style="font-family:sans-serif;text-align:center;padding:50px;">
                <h2 style="color:#2e7d32;">Otorisasi Google Drive Berhasil!</h2>
                <p>Anda dapat menutup tab ini dan kembali ke terminal Anda.</p>
                </body></html>
                """
                self.wfile.write(html.encode("utf-8"))
            else:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Error: Code parameter missing.")

        def log_message(self, format, *args):
            pass

    server = http.server.HTTPServer(("127.0.0.1", 8085), OAuthHandler)
    server.timeout = 180  # timeout 3 menit

    print("\nBuka tautan otorisasi berikut di peramban (browser) Anda:")
    print("-" * 70)
    print(auth_url)
    print("-" * 70)
    print("Menunggu konfirmasi login dari browser (port 8085)...")

    # Buka otomatis jika xdg-open / termux-open-url tersedia
    if shutil.which("termux-open-url"):
        subprocess.run(["termux-open-url", auth_url], check=False)
    elif shutil.which("xdg-open"):
        subprocess.run(["xdg-open", auth_url], check=False)

    while auth_code_container["code"] is None:
        server.handle_request()

    code = auth_code_container["code"]
    print("\n[OK] Kode otorisasi diterima! Menukarkan dengan refresh token...")

    # Tukar code dengan refresh token
    token_url = "https://oauth2.googleapis.com/token"
    token_payload = urllib.parse.urlencode({
        "client_id": client_id,
        "client_secret": client_secret,
        "code": code,
        "grant_type": "authorization_code",
        "redirect_uri": redirect_uri
    }).encode("utf-8")

    req = urllib.request.Request(token_url, data=token_payload, headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            refresh_token = data.get("refresh_token")
            if not refresh_token:
                print("Peringatan: Google tidak mengembalikan refresh token baru. Pastikan 'prompt=consent' digunakan.")
                return

            print("\n" + "\033[92m" + "SUKSES! Refresh token berhasil didapatkan:" + "\033[0m")
            print(f"Refresh Token: {refresh_token}\n")

            # Tanya lokasi simpan
            target_path = GLOBAL_CONFIG_PATH
            cfg, _ = load_config(Path.cwd())
            if not cfg:
                cfg = get_default_config_template()

            cfg["gdrive"]["client_id"] = client_id
            cfg["gdrive"]["client_secret"] = client_secret
            cfg["gdrive"]["refresh_token"] = refresh_token
            save_config(cfg, target_path)
            print(f"Konfigurasi Google Drive tersimpan otomatis di: {target_path}\n")

    except Exception as e:
        print(f"Gagal menukarkan token: {e}")


def interactive_init(target_dir):
    """Wizard pembuatan file konfigurasi interaktif."""
    print("\n" + "="*70)
    print("  SETUP KONFIGURASI AUTO BACKUP")
    print("="*70)

    cfg, _ = load_config(target_dir)
    if not cfg:
        cfg = get_default_config_template()

    print("\nPilih lokasi penyimpanan file konfigurasi:")
    print(f"1. Global ({GLOBAL_CONFIG_PATH}) -> Berlaku untuk SEMUA folder di komputer/HP ini")
    print(f"2. Lokal ({target_dir / LOCAL_CONFIG_NAME}) -> Khusus untuk folder ini saja")
    pilihan_lokasi = input("Pilihan (1/2, default 1): ").strip()
    save_target = (target_dir / LOCAL_CONFIG_NAME) if pilihan_lokasi == "2" else GLOBAL_CONFIG_PATH

    print("\n--- PENGATURAN GITHUB ---")
    use_gh = input("Aktifkan backup ke GitHub? (Y/n): ").strip().lower() != 'n'
    cfg["github"]["enabled"] = use_gh
    if use_gh:
        repo_default = cfg["github"].get("repo", "")
        repo = input(f"GitHub Repository (contoh: username/skripsi-backup) [{repo_default}]: ").strip()
        if repo:
            cfg["github"]["repo"] = repo

        token_default = cfg["github"].get("token", "")
        print("\nInfo Token GitHub:")
        print("Buat di: https://github.com/settings/tokens (beri centang pada hak akses 'repo')")
        print("Atau jika sudah login via 'gh auth login', Anda bisa mengosongkan token ini.")
        token = input(f"Personal Access Token GitHub [{token_default[:10]}...]: ").strip()
        if token:
            cfg["github"]["token"] = token

    print("\n--- PENGATURAN GOOGLE DRIVE ---")
    use_gd = input("Aktifkan backup ke Google Drive? (Y/n): ").strip().lower() != 'n'
    cfg["gdrive"]["enabled"] = use_gd
    if use_gd:
        print("Pilih metode Google Drive:")
        print("1. OAuth REST API (Otomatis & Tanpa instal tool tambahan)")
        print("2. Rclone (Menggunakan remote rclone yang sudah dikonfigurasi)")
        gd_mode = input("Pilihan (1/2, default 1): ").strip()

        if gd_mode == "2":
            cfg["gdrive"]["method"] = "rclone"
            remote = input("Nama remote rclone [gdrive]: ").strip() or "gdrive"
            cfg["gdrive"]["rclone_remote"] = remote
            folder = input("Folder tujuan di rclone (opsional): ").strip()
            cfg["gdrive"]["folder_id"] = folder
        else:
            cfg["gdrive"]["method"] = "oauth"
            folder = input("ID Folder Google Drive tujuan (kosongkan jika di root): ").strip()
            cfg["gdrive"]["folder_id"] = folder
            print("\nCatatan: Untuk mengkoneksikan OAuth Google Drive dengan browser,")
            print("jalankan perintah berikut setelah setup ini:")
            print("  python3 auto_backup.py --setup-gdrive\n")

    print("\n--- PENGATURAN SALINAN DRIVE LOKAL (DATA E & F) ---")
    use_local = input("Aktifkan salinan otomatis ke drive lokal (Data E & F)? (Y/n): ").strip().lower() != 'n'
    cfg["local_drives"] = cfg.get("local_drives", {})
    cfg["local_drives"]["enabled"] = use_local
    if use_local:
        default_paths = ", ".join(cfg["local_drives"].get("paths", ["E:/Backup", "F:/Backup"]))
        print(f"Path drive tujuan (pisahkan dengan koma) [default: {default_paths}]:")
        paths_input = input("Target paths: ").strip()
        if paths_input:
            cfg["local_drives"]["paths"] = [p.strip() for p in paths_input.split(",") if p.strip()]
        else:
            cfg["local_drives"]["paths"] = ["E:/Backup", "F:/Backup"]

    save_config(cfg, save_target)
    print(f"\n[OK] Setup selesai! Konfigurasi tersimpan di: {save_target}")


# ============================================================================
# MAIN ORCHESTRATION PIPELINE
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Auto Backup: Zip folder saat ini & upload ke GitHub Releases + Google Drive"
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=None,
        help="Folder yang ingin di-backup (default: folder tempat script ini berada)"
    )
    parser.add_argument(
        "--init",
        action="store_true",
        help="Jalankan wizard konfigurasi interaktif untuk mengatur GitHub & Drive"
    )
    parser.add_argument(
        "--setup-gdrive",
        action="store_true",
        help="Buka wizard otorisasi Google Drive OAuth untuk mendapatkan refresh token"
    )
    parser.add_argument(
        "--no-upload",
        action="store_true",
        help="Hanya buat file ZIP secara lokal tanpa mengunggah ke GitHub atau Drive"
    )
    parser.add_argument(
        "--no-local",
        action="store_true",
        help="Lewati penyalinan ke drive lokal (Data E & F)"
    )
    parser.add_argument(
        "--local-drives",
        nargs="+",
        default=None,
        help="Daftar drive lokal tujuan (contoh: --local-drives E:/Backup F:/Backup)"
    )
    parser.add_argument(
        "--delete-zip",
        action="store_true",
        help="Hapus file ZIP lokal setelah selesai diunggah ke cloud"
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"Auto Backup Tool v{VERSION}"
    )

    args = parser.parse_args()

    # 1. Deteksi Target Directory
    if args.target:
        target_dir = Path(args.target).resolve()
        if not target_dir.is_dir():
            print(f"\033[91mError: Path target '{args.target}' bukan direktori valid.\033[0m")
            sys.exit(1)
    else:
        # Default: Folder tempat script ini disimpan!
        target_dir = Path(__file__).resolve().parent

    # Jalankan Setup Wizard jika diminta
    if args.setup_gdrive:
        setup_gdrive_oauth()
        return

    if args.init:
        interactive_init(target_dir)
        return

    folder_name = target_dir.name

    print("\n" + "="*70)
    print(f"  AUTO BACKUP TOOL v{VERSION}  |  Target: {folder_name}")
    print("="*70)
    log("INFO", f"Lokasi Folder : {target_dir}")
    log("INFO", f"Waktu Mulai   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # 2. Muat Konfigurasi
    config, cfg_path = load_config(target_dir)
    if not config and not args.no_upload:
        log("WARN", "File konfigurasi belum ditemukan.")
        print("\nSilakan buat konfigurasi terlebih dahulu dengan menjalankan:")
        print("  python3 auto_backup.py --init")
        print("Atau buat backup ZIP lokal saja dengan:")
        print("  python3 auto_backup.py --no-upload\n")
        sys.exit(1)

    if cfg_path:
        log("INFO", f"Memuat config : {cfg_path}")

    # 3. Buat File ZIP
    custom_excludes = []
    if config:
        custom_excludes = config.get("options", {}).get("custom_excludes", [])

    zip_path = create_backup_zip(target_dir, custom_excludes)
    if not zip_path or not zip_path.is_file():
        log("ERROR", "Proses pembuatan ZIP dibatalkan atau gagal.")
        sys.exit(1)

    if args.no_upload:
        log("SUCCESS", f"Mode --no-upload aktif. Backup ZIP tersimpan di: {zip_path}")
        print("="*70 + "\n")
        return

    # 4. Upload ke GitHub & Google Drive
    print("\n" + "-"*70)
    print("  MEMULAI PROSES UPLOAD KE CLOUD")
    print("-" * 70)

    gh_success = True
    gd_success = True

    # GitHub
    if config.get("github", {}).get("enabled", True):
        gh_success = upload_to_github(config, zip_path, folder_name)
    else:
        log("INFO", "GitHub backup dilewati (disabled).")

    # Google Drive
    if config.get("gdrive", {}).get("enabled", True):
        gd_success = upload_to_gdrive(config, zip_path)
    else:
        log("INFO", "Google Drive backup dilewati (disabled).")

    # 5. Salin ke Drive Lokal Tambahan (Data E & Data F)
    local_results = []
    if config:
        local_results = copy_to_local_drives(
            config,
            zip_path,
            folder_name,
            cli_override_paths=args.local_drives,
            skip_local=args.no_local
        )

    # 6. Ringkasan & Opsi Penghapusan File Lokal Asal
    print("\n" + "="*70)
    print("  RINGKASAN STATUS BACKUP")
    print("="*70)
    print(f"• Folder Asal   : {target_dir}")
    print(f"• Berkas ZIP    : {zip_path.name} ({format_size(zip_path.stat().st_size)})")
    print(f"• Status GitHub : {'\033[92mBERHASIL\033[0m' if gh_success else '\033[91mGAGAL / MELEWATI\033[0m'}")
    print(f"• Status Drive  : {'\033[92mBERHASIL\033[0m' if gd_success else '\033[91mGAGAL / MELEWATI\033[0m'}")

    if local_results:
        print("• Status Salinan Lokal (Data E & F):")
        for raw_p, ok, detail in local_results:
            st = "\033[92mBERHASIL\033[0m" if ok else "\033[93mDILEWATI / TIDAK TERPASANG\033[0m"
            print(f"  - {raw_p:<15} : {st} ({detail})")
    elif args.no_local:
        print("• Status Salinan Lokal: DILEWATI (--no-local)")
    elif config and not config.get("local_drives", {}).get("enabled", True):
        print("• Status Salinan Lokal: DINONAKTIFKAN (Config)")

    # Hapus file ZIP sumber jika diminta
    delete_local = args.delete_zip or config.get("options", {}).get("delete_local_on_success", False)
    if delete_local and gh_success and gd_success:
        try:
            zip_path.unlink()
            log("INFO", f"File ZIP sumber telah dihapus untuk menghemat ruang penyimpanan.")
        except OSError as e:
            log("WARN", f"Gagal menghapus file ZIP sumber: {e}")
    else:
        log("INFO", f"Salinan lokal ZIP dipertahankan di: {zip_path}")

    print("="*70 + "\n")


if __name__ == "__main__":
    main()
