# ==========================================================
#   ANTIGRAVITY (AGY) FULL ECOSYSTEM INSTALLER FOR WINDOWS
#   Skills (776) + Plugins (36) + MCPs (16) + Always-On Rules
# ==========================================================

$ErrorActionPreference = "Stop"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   ANTIGRAVITY FULL ECOSYSTEM INSTALLER (WINDOWS)" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$userProfile = [System.Environment]::GetFolderPath('UserProfile')
$targetDir = Join-Path $userProfile ".gemini"
$configDir = Join-Path $targetDir "config"
$cliDir = Join-Path $targetDir "antigravity-cli"
$skillsDir = Join-Path $configDir "skills"
$pluginsDir = Join-Path $configDir "plugins"
$rulesDir = Join-Path $configDir "rules"

foreach ($d in @($configDir, $cliDir, $skillsDir, $pluginsDir, $rulesDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

Write-Host "[1/5] Menyalin 776 Skills & Index..." -ForegroundColor Yellow
Copy-Item -Path "config\skills\*" -Destination $skillsDir -Recurse -Force
Copy-Item -Path "config\skills.json" -Destination (Join-Path $configDir "skills.json") -Force

Write-Host "[2/5] Menyalin 36 Plugins & Memetakan Plugin Skills..." -ForegroundColor Yellow
Copy-Item -Path "config\plugins\*" -Destination $pluginsDir -Recurse -Force
if (Test-Path "config\plugin_skills_map.json") {
    $psMap = Get-Content "config\plugin_skills_map.json" -Raw | ConvertFrom-Json
    foreach ($prop in $psMap.PSObject.Properties) {
        $pSkillRoot = Join-Path (Join-Path $pluginsDir $prop.Name) "skills"
        if (-not (Test-Path $pSkillRoot)) { New-Item -ItemType Directory -Path $pSkillRoot -Force | Out-Null }
        foreach ($sName in $prop.Value) {
            $srcSkill = Join-Path $skillsDir $sName
            if (Test-Path $srcSkill) {
                Copy-Item -Path $srcSkill -Destination (Join-Path $pSkillRoot $sName) -Recurse -Force
            }
        }
    }
}

Write-Host "[3/5] Memasang Always-On Rules, AGENTS.md & GEMINI.md..." -ForegroundColor Yellow
Copy-Item -Path "config\GEMINI.md" -Destination (Join-Path $configDir "GEMINI.md") -Force
Copy-Item -Path "config\GEMINI.md" -Destination (Join-Path $targetDir "GEMINI.md") -Force
Copy-Item -Path "config\AGENTS.md" -Destination (Join-Path $configDir "AGENTS.md") -Force
Copy-Item -Path "config\rules\*" -Destination $rulesDir -Recurse -Force

Write-Host "[4/5] Mengaktifkan Registry Plugin (config.json) & 16 MCP Servers (mcp_config.json)..." -ForegroundColor Yellow
$cfgTarget = Join-Path $configDir "config.json"
if (-not (Test-Path $cfgTarget)) {
    Copy-Item -Path "config\config.json" -Destination $cfgTarget -Force
} else {
    python -c "import json; p=r'$cfgTarget'; b=json.load(open('config/config.json',encoding='utf-8')); c=json.load(open(p,encoding='utf-8')); c.setdefault('plugins',{}).update(b['plugins']); json.dump(c,open(p,'w',encoding='utf-8'),indent=2)"
}

$mcpTarget = Join-Path $configDir "mcp_config.json"
$rawMcp = (Get-Content "config\mcp_config.json" -Raw).Replace("__HOME__", $userProfile.Replace("\", "\\"))
if (-not (Test-Path $mcpTarget)) {
    [System.IO.File]::WriteAllText($mcpTarget, $rawMcp, [System.Text.Encoding]::UTF8)
} else {
    $tmpMcp = Join-Path $env:TEMP "agy_bundle_mcp.json"
    [System.IO.File]::WriteAllText($tmpMcp, $rawMcp, [System.Text.Encoding]::UTF8)
    python -c "import json; t=r'$mcpTarget'; n=json.load(open(r'$tmpMcp',encoding='utf-8')); c=json.load(open(t,encoding='utf-8')); s=c.setdefault('mcpServers',{}); [s.setdefault(k,v) for k,v in n['mcpServers'].items()]; json.dump(c,open(t,'w',encoding='utf-8'),indent=2)"
    Remove-Item $tmpMcp -Force -ErrorAction SilentlyContinue
}

Write-Host "[5/5] Mengonfigurasi CLI Settings & Always-Allow Permissions..." -ForegroundColor Yellow
$settingsPath = Join-Path $cliDir "settings.json"
$escapedUserProfile = $userProfile.Replace("\", "/")
$settingsContent = @"
{
  "agentMode": "accept-edits",
  "allowNonWorkspaceAccess": true,
  "artifactReviewPolicy": "always-proceed",
  "model": "Gemini 3.8 Flash (High)",
  "notifications": true,
  "permissions": {
    "allow": [
      "*",
      "command(*)",
      "read_file(*)",
      "write_file(*)",
      "edit_file(*)",
      "search_web(*)",
      "manage_task(*)",
      "manage_subagents(*)",
      "invoke_subagent(*)",
      "schedule(*)"
    ]
  },
  "runningLightSpeed": "fast",
  "toolPermission": "always-proceed",
  "trustedWorkspaces": [
    "$escapedUserProfile"
  ],
  "useG1Credits": true,
  "verbosity": "high"
}
"@
[System.IO.File]::WriteAllText($settingsPath, $settingsContent, [System.Text.Encoding]::UTF8)

Write-Host ""
Write-Host "==========================================================" -ForegroundColor Green
Write-Host " [SUCCESS] 776 Skills, 36 Plugins, 16 MCPs & Always-On Rules" -ForegroundColor Green
Write-Host "           berhasil terpasang di $targetDir" -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Green
