# 📦 Panduan Auto Backup ke GitHub & Google Drive

Script otomatis portabel berkinerja tinggi untuk membuat arsip ZIP dari sebuah folder dan mengunggahnya secara bersamaan ke **GitHub Releases** dan **Google Drive**.

Script: [`auto_backup.py`](file:///sdcard/Antigravity/auto_backup.py)

---

## 🎯 Cara Kerja & Filosofi

1. **Auto-Detection (Otomatis Mendeteksi Folder)**:
   - Cukup salin `auto_backup.py` ke dalam folder yang ingin dicadangkan (misalnya di folder `SKRIPSI/auto_backup.py`).
   - Jalankan `python3 auto_backup.py`.
   - Script akan otomatis mendeteksi bahwa ia berada di dalam folder `SKRIPSI`, lalu membuat arsip ZIP bernama:
     ```
     SKRIPSI_backup_YYYYMMDD_HHMMSS.zip
     ```
2. **Smart Exclusion (Filter Otomatis)**:
   - Script otomatis mengabaikan berkas `auto_backup.py` itu sendiri dari dalam ZIP.
   - Mengabaikan berkas konfigurasi rahasia (`backup_config.json`, `.backup_config.json`, `.env`).
   - Mengabaikan arsip ZIP yang dibuat sebelumnya (`*.zip`).
   - Mengabaikan file *lock* sementara Microsoft Word/Excel (`~$*`, `*.tmp`).
   - Mengabaikan direktori git (`.git/`) dan cache (`__pycache__`, `node_modules`).
3. **Penyimpanan Cloud Ganda & Salinan Lokal (Data E & F)**:
   - **GitHub**: Menggunakan GitHub Releases API (mendukung file hingga 2GB tanpa membuat ukuran git repository membengkak).
   - **Google Drive**: Menggunakan Google Drive Resumable Upload API v3 (atau Rclone) langsung ke Google Drive Anda.
   - **Local Drives (Data E & Data F)**: Otomatis mendeteksi dan menyalin berkas ZIP ke drive `E:\` dan `F:\` (misal: `E:\Backup` dan `F:\Backup` di Windows/WSL, atau direktori penyimpanan eksternal di Android/Linux).
4. **Zero Dependency**:
   - Dibuat 100% menggunakan Python Standard Library bawaan (tidak memerlukan `pip install` rumit).

---

## 🚀 Panduan Penggunaan Singkat

### Langkah 1: Siapkan Konfigurasi Awal (Sekali Saja)

Jalankan wizard konfigurasi interaktif:
```bash
python3 /sdcard/Antigravity/auto_backup.py --init
```
Wizard akan menanyakan:
- Lokasi konfigurasi: Pilih **Global (1)** agar konfigurasi tersimpan di `~/.backup_config.json` dan berlaku untuk seluruh folder di perangkat Anda tanpa perlu disetting ulang.
- Data repository GitHub dan token.
- Metode Google Drive yang diinginkan.

---

### Langkah 2: Setup Kredensial

#### A. Konfigurasi GitHub
Pilih salah satu dari 2 cara termudah:
- **Cara 1 (GitHub CLI - Direkomendasikan jika sudah terpasang)**:
  Cukup login sekali di terminal:
  ```bash
  gh auth login
  ```
  Di konfigurasi, cukup isi nama repository tujuan (contoh: `username/skripsi-backup`). Tool akan otomatis menggunakan `gh release create`.
- **Cara 2 (Personal Access Token)**:
  1. Buka [GitHub Tokens](https://github.com/settings/tokens) (Classic).
  2. Klik **Generate new token (classic)**.
  3. Beri nama (misal: `backup-token`), masa aktif (No expiration atau 90 hari), dan centang izin:
     - `repo` (Full control of private repositories).
  4. Salin token (dimulai dengan `ghp_...`).
  5. Masukkan ke konfigurasi.

> [!TIP]
> Buat repository GitHub tujuan dalam mode **Private** agar draf naskah skripsi atau dokumen pribadi Anda tetap aman dan tidak dapat diakses publik.

---

#### B. Konfigurasi Google Drive
Pilih salah satu dari 2 metode:

##### Opsi 1: Google OAuth2 API (Built-in Otomatis - Tanpa Tool Tambahan)
1. Buka [Google Cloud Console](https://console.cloud.google.com).
2. Buat Project baru (misal: `Backup-Pribadi`).
3. Buka **APIs & Services > Library**, cari **Google Drive API**, lalu klik **Enable**.
4. Buka **OAuth consent screen**:
   - Pilih User Type: **External** (atau Testing).
   - Isi App Name & Email.
   - Pada bagian **Test users**, tambahkan alamat email Google Drive Anda.
5. Buka **Credentials > Create Credentials > OAuth client ID**:
   - Application type: **Web application** (atau Desktop app).
   - Authorized redirect URIs: tambahkan `http://localhost:8085`.
   - Simpan dan salin **Client ID** serta **Client Secret**.
6. Jalankan wizard otomatis pada terminal:
   ```bash
   python3 /sdcard/Antigravity/auto_backup.py --setup-gdrive
   ```
   - Masukkan Client ID & Client Secret.
   - Terminal akan membuka peramban / memberikan tautan login Google.
   - Klik **Allow** / Izinkan.
   - Script akan otomatis menangkap `refresh_token` dan menyimpannya.

##### Opsi 2: Menggunakan Rclone (Sangat Populer di Termux / Linux)
Jika Anda sudah memiliki remote Google Drive di Rclone:
1. Pastikan rclone terpasang: `pkg install rclone`
2. Konfigurasi remote Google Drive: `rclone config` (beri nama misalnya `gdrive`)
3. Di file konfigurasi `backup_config.json`, atur:
   ```json
   "gdrive": {
     "enabled": true,
     "method": "rclone",
     "rclone_remote": "gdrive",
     "folder_id": "Backup_Skripsi"
   }
   ```

---

## 💻 Cara Menjalankan Backup

### Skenario 1: Simpan Script di Folder Target (Sesuai Permintaan Anda)
Salin `auto_backup.py` ke dalam folder skripsi Anda:
```bash
cp /sdcard/Antigravity/auto_backup.py /sdcard/Antigravity/SKRIPSI/
cd /sdcard/Antigravity/SKRIPSI
python3 auto_backup.py
```
Script akan:
1. Mendeteksi bahwa ia berada di dalam folder `SKRIPSI`.
2. Mengompresi seluruh isi folder `SKRIPSI` menjadi file ZIP (misal: `SKRIPSI_backup_20261103_130000.zip`).
3. Mengunggah ke GitHub Releases di repository yang Anda tentukan.
4. Mengunggah ke Google Drive Anda.
5. Memberikan tautan unduhan langsung.

---

### Skenario 2: Jalankan dari Mana Saja dengan Menunjuk Folder
Anda juga tidak harus menyalin script berkali-kali. Cukup panggil script utama dan tentukan foldernya:
```bash
python3 /sdcard/Antigravity/auto_backup.py /sdcard/Antigravity/SKRIPSI
```

---

### Skenario 3: Uji Coba ZIP Lokal Saja (Tanpa Upload)
```bash
python3 auto_backup.py --no-upload
```

### Skenario 4: Hapus File ZIP Lokal Setelah Upload Sukses (Hemat Ruang HP)
```bash
python3 auto_backup.py --delete-zip
```
*(Catatan: Salinan cadangan di Drive E dan Drive F tetap aman dan tidak akan ikut terhapus).*

### Skenario 5: Salin ke Drive Tertentu Langsung dari Terminal
```bash
python3 auto_backup.py --local-drives "E:/Backup" "F:/Backup"
```
Atau jika ingin melewatkan penyalinan ke drive lokal sementara:
```bash
python3 auto_backup.py --no-local
```

---

## ⚙️ Struktur File Konfigurasi (`backup_config.json`)

File konfigurasi dapat diletakkan di:
- **Global**: `~/.backup_config.json` (berlaku untuk semua folder)
- **Lokal**: `backup_config.json` di dalam folder proyek (menimpa pengaturan global jika ingin repository/folder Drive yang berbeda untuk proyek tertentu).

Contoh isi berkas:
```json
{
  "github": {
    "enabled": true,
    "repo": "username/skripsi-backup",
    "token": "ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "method": "auto"
  },
  "gdrive": {
    "enabled": true,
    "method": "oauth",
    "client_id": "xxxxxxxx.apps.googleusercontent.com",
    "client_secret": "GOCSPX-xxxxxxxx",
    "refresh_token": "1//xxxxxxxx",
    "folder_id": "",
    "rclone_remote": "gdrive"
  },
  "local_drives": {
    "enabled": true,
    "paths": [
      "E:/Backup",
      "F:/Backup"
    ]
  },
  "options": {
    "keep_local_zip": true,
    "custom_excludes": [
      "*.mp4",
      "dataset_besar/*"
    ]
  }
}
```

---

## ⚡ Bonus: Membuat Shortcut Perintah `backup` di Terminal

Agar Anda bisa mencadangkan folder mana saja hanya dengan mengetik `backup`:
1. Buka berkas `~/.bashrc`:
   ```bash
   echo 'alias backup="python3 /sdcard/Antigravity/auto_backup.py"' >> ~/.bashrc
   source ~/.bashrc
   ```
2. Sekarang, masuk ke folder apapun (misal `cd /sdcard/Antigravity/SKRIPSI`), lalu cukup ketik:
   ```bash
   backup
   ```
   Folder tersebut akan langsung otomatis di-zip dan diunggah ke GitHub & Google Drive!
