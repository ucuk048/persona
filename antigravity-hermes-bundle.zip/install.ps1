# ==========================================================
#    HERMES AGENT CONFIGURATION INSTALLER (WINDOWS)
# ==========================================================

$ErrorActionPreference = "Stop"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "    HERMES AGENT CONFIGURATION INSTALLER (WINDOWS)" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$userProfile = [System.Environment]::GetFolderPath('UserProfile')
$hermesDir = Join-Path $userProfile ".hermes"
$skillsDir = Join-Path $hermesDir "skills"

Write-Host "[1/3] Membuat direktori target di $hermesDir..." -ForegroundColor Yellow
if (-not (Test-Path $hermesDir)) { New-Item -ItemType Directory -Path $hermesDir -Force | Out-Null }
if (-not (Test-Path $skillsDir)) { New-Item -ItemType Directory -Path $skillsDir -Force | Out-Null }

Write-Host "[2/3] Menyalin 633 Skills ke $skillsDir..." -ForegroundColor Yellow
Copy-Item -Path "skills\*" -Destination $skillsDir -Recurse -Force

Write-Host "[3/3] Memasang SOUL.md..." -ForegroundColor Yellow
$soulPath = Join-Path $hermesDir "SOUL.md"
if (Test-Path $soulPath) {
    Copy-Item -Path $soulPath -Destination (Join-Path $hermesDir "SOUL.md.bak") -Force
}
Copy-Item -Path "SOUL.md" -Destination $soulPath -Force

Write-Host ""
Write-Host "==========================================================" -ForegroundColor Green
Write-Host " [SUCCESS] Seluruh 633 skills & persona SOUL.md berhasil" -ForegroundColor Green
Write-Host "           terpasang pada Hermes Agent di laptop Windows!" -ForegroundColor Green
Write-Host " Lokasi SOUL  : $soulPath" -ForegroundColor Green
Write-Host " Lokasi Skills: $skillsDir" -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Green
