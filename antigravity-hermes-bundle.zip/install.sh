#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "    HERMES AGENT (NOUS RESEARCH) CONFIGURATION INSTALLER"
echo "=========================================================="

HERMES_DIR="$HOME/.hermes"
SKILLS_DIR="$HERMES_DIR/skills"

echo "[1/3] Membuat direktori target di $HERMES_DIR..."
mkdir -p "$HERMES_DIR"
mkdir -p "$SKILLS_DIR"

echo "[2/3] Menyalin 633 Skills ke $SKILLS_DIR..."
cp -r skills/* "$SKILLS_DIR/"

echo "[3/3] Memasang SOUL.md (Identitas & Protokol 9-Fase)..."
if [ -f "$HERMES_DIR/SOUL.md" ]; then
    echo "  - Backup SOUL.md lama ke SOUL.md.bak..."
    cp "$HERMES_DIR/SOUL.md" "$HERMES_DIR/SOUL.md.bak"
fi
cp SOUL.md "$HERMES_DIR/SOUL.md"

echo ""
echo "=========================================================="
echo " [SUCCESS] Seluruh 633 skills & persona SOUL.md berhasil"
echo "           terpasang pada Hermes Agent di laptop Anda!"
echo " Lokasi SOUL  : $HERMES_DIR/SOUL.md"
echo " Lokasi Skills: $SKILLS_DIR"
echo "=========================================================="
