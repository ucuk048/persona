---
name: auto-fullstack
description: Automatically orchestrates the entire full-stack development lifecycle (Inspection, PRD, Interactive Stack Selection, Structure, Tasks, UI/UX, Backend, Database, DevOps, Testing, Security Audit, Observability, Anti-Slop) whenever the user asks to build an application, website, POS, dashboard, or SaaS.
---

# Auto Full-Stack Master Orchestrator

Gunakan skill ini secara otomatis setiap kali pengguna meminta pembuatan aplikasi, web, sistem informasi, POS, toko online, dashboard, atau modul perangkat lunak lengkap.

## Alur Kerja Inisiasi Proyek (Discovery & Inception Protocol)

Sebelum mengeksekusi kode, agen WAJIB menjalankan protokol pra-pemeriksaan direktori dan interaksi arsitektur:

### 1. Pre-Flight Directory Check (Pengecekan Awal Direktori)
Setiap kali memulai prompt proyek:
- Periksa direktori kerja target proyek di `<workspace>/<nama-proyek>/`.
- Periksa berkas yang sudah ada: apakah folder baru, atau sudah ada berkas proyek seperti `PRD.md`, `STRUCTURE.md`, `TASKS.md`, `package.json`, `composer.json`, `requirements.txt`, dll.

### 2. Penanganan Berkas PRD Eksisting
- **Jika `PRD.md` SUDAH ADA di folder tersebut:**
  - JANGAN menimpa (*do NOT overwrite*) berkas secara sembarangan.
  - Baca `PRD.md` eksisting untuk memahami batasan sistem dan fitur yang sudah disepakati sebelumnya.
  - Baca `TASKS.md` untuk melihat status progres: task mana yang sudah centang `[x]` (selesai) dan task mana yang masih `[ ]` (belum selesai).
  - Tanyakan kepada pengguna apakah ada perubahan/penambahan kebutuhan (revisi scope) atau langsung melanjutkan tugas berikutnya yang belum selesai di `TASKS.md`.
- **Jika `PRD.md` BELUM ADA (Proyek Baru):**
  - Buat draft awal `PRD.md` berdasarkan ide atau deskripsi prompt pengguna (Problem, Persona, Functional Specs, Non-Functional Specs, Edge Cases, Acceptance Criteria).

### 3. Konfirmasi Interaktif Struktur & Tech Stack (`ask_question`)
Setelah `PRD.md` siap atau disepakati, agen WAJIB mengonfirmasi preferensi teknologi kepada pengguna melalui dialog interaktif / pertanyaan pilihan ganda (`ask_question`):
- **Backend Language & Framework**: Laravel (PHP) / FastAPI (Python) / NestJS atau Express (TypeScript) / Go (Golang) / Spring Boot (Java) / Pure PHP?
- **Database**: PostgreSQL / MySQL / MariaDB / SQLite / MongoDB?
- **Frontend & UI**: Next.js (React) / Nuxt (Vue) / Blade + Alpine + Tailwind / Pure HTML+CSS+JS modern?
- **Pola Arsitektur**: Monolith Modular vs Terpisah (Headless REST API + SPA Frontend).

### 4. Penyusunan `STRUCTURE.md` & `TASKS.md`
Berdasarkan hasil pilihan teknologi pengguna di Langkah 3:
- **`STRUCTURE.md`**: Buat cetak biru pohon direktori modular yang 100% presisi sesuai framework & database yang dipilih.
- **`TASKS.md`**: Susun checklist tugas bertahap (Sprint/Phase) dari inisialisasi lingkungan hingga rilis siap pakai.

---

## Eksekusi Bertahap (The 9-Phase Engineering Lifecycle)

Setelah Fase 0 (PRD, Stack Confirmation, Structure, Tasks) disepakati, jalankan eksekusi task demi task:

1. **Fase 1: Arsitektur & Desain API (`api-design`, `architecture-decision-records`)**: Kontrak endpoint OpenAPI/Swagger.
2. **Fase 2: Skema Database, Relasi & Data Seeding (`database-migrations`, `postgres-patterns`/`mysql-patterns`/`prisma-patterns`)**: Migrasi skema dan script seeder data demo.
3. **Fase 3: Backend, Business Logic & Caching (`backend-patterns`, `redis-patterns`, `error-handling`)**: Controller/Service/Repository, validation, rate limiting.
4. **Fase 4: Desain Antarmuka & UI/UX Frontend (`design-system`, `frontend-design-direction`, `make-interfaces-feel-better`, `motion-patterns`, `antislop-layoutmobile`, `frontend-a11y`, `antislop-ui`)**: UI profesional, responsif mobile, micro-interactions, navigasi keyboard.
5. **Fase 5: Audit Keamanan Mendalam & Hardening (`security-audit`, `security-guardian`)**: OWASP Top 10, sanitasi input, RBAC role guard, secret scanning.
6. **Fase 6: DevOps, Containerization & Observabilitas (`docker-patterns`, `git-workflow`)**: Dockerfile multi-stage, `docker-compose.yml`, health check (`/health`), structured logging.
7. **Fase 7: Pengujian & Quality Assurance (`rtk-tdd`, `browser-qa`, `verify-and-stop`)**: Unit test alur kritis, browser verification.
8. **Fase 8: Pembersihan & Anti-Slop (`antislop-code`, `ponytail`)**: Bersihkan komentar AI sampah dan minimalkan dependensi berlebih (YAGNI).
