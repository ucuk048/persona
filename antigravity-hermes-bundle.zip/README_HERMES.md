# PANDUAN INTEGRASI KONFIGURASI PADA HERMES AGENT (NOUS RESEARCH)

Paket bundle ini mengonfigurasi **Hermes Agent** di laptop Anda dengan seluruh kapabilitas yang sama persis:
- **503 Skills Aktif**: Dimuat ke dalam direktori `~/.hermes/skills/` (menggunakan standar `agentskills.io`).
- **SOUL.md**: Identitas sistem global Slot #1 yang mengunci persona **Ponytail (FULL)**, **Caveman (FULL)**, **Anti-Slop**, serta **Protokol 9-Fase Fullstack**.
- **Project Rules**: Berkas `AGENTS.md` & `.hermes.md` untuk disalin ke folder proyek bila diperlukan.

---

## Cara Pasang di Laptop

1. Unduh dan ekstrak berkas `antigravity-hermes-bundle.zip` di laptop Anda.
2. Jalankan installer sesuai sistem operasi:
   - **Windows:** Klik dua kali pada `install.bat` (atau jalankan `.\install.ps1` via PowerShell).
   - **Linux / macOS / WSL:** Buka terminal dan jalankan:
     ```bash
     chmod +x install.sh
     ./install.sh
     ```
3. Skrip otomatis menempatkan skills di `~/.hermes/skills/` dan identitas di `~/.hermes/SOUL.md`.

---

## Cara Penggunaan di Hermes Agent

Buka terminal di laptop dan jalankan Hermes:
```bash
hermes
```

### 1. Slash Commands
Seluruh 503 skill langsung terpetakan menjadi slash commands otomatis di Hermes TUI, misalnya:
- `/auto-fullstack` : Menjalankan orkestrator fullstack otomatis.
- `/ponytail` : Mode lazy senior dev.
- `/caveman` : Mode ringkas padat hemat token.
- `/security-audit` : Menjalankan audit keamanan OWASP.
- `/design-system` : Men-generate design system & CSS tokens.

### 2. Prompt Natural
Anda juga dapat langsung memberikan prompt:
> *"Buatkan website POS kasir retail lengkap"*

Hermes Agent akan membaca `SOUL.md`, menjalankan pre-flight check, menyusun draft `PRD.md`, menanyakan preferensi stack, lalu mengeksekusi pipeline bertahap.
