@echo off
echo ==========================================================
echo     HERMES AGENT INSTALLER FOR WINDOWS (CMD)
echo ==========================================================
echo Menjalankan skrip PowerShell instalasi...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
