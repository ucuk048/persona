# Hermes Agent Skills Updater for Windows PowerShell
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
python (Join-Path $scriptDir "update_skills.py") hermes
