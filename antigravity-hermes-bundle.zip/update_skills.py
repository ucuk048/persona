#!/usr/bin/env python3
"""
Universal Antigravity Skills Updater for Laptop / Desktop (Windows, macOS, Linux)
Memperbarui seluruh 367+ skills langsung dari repositori GitHub hulu ke instalasi lokal.
"""

import os
import sys
import subprocess
import json

REPOS = {
    "ECC": "https://github.com/ucuk048/ECC.git",
    "anti-slop": "https://github.com/ucuk048/anti-slop.git",
    "caveman": "https://github.com/JuliusBrussee/caveman.git",
    "rtk": "https://github.com/rtk-ai/rtk.git",
    "genoffice": "https://github.com/ucuk048/genoffice.git",
    "graphify": "https://github.com/ucuk048/graphify.git",
    "humanizer": "https://github.com/ucuk048/humanizer.git",
    "ponytail": "https://github.com/ucuk048/ponytail.git",
    "security-audit-skill": "https://github.com/ucuk048/security-audit-skill.git",
    "tv-detox": "https://github.com/ucuk048/tv-detox.git",
    "video-demo": "https://github.com/ucuk048/video-demo.git"
}

def get_target_dir():
    # Detect if Hermes or Antigravity
    home = os.path.expanduser("~")
    # Check command line arg
    if len(sys.argv) > 1 and sys.argv[1].lower() == "hermes":
        return os.path.join(home, ".hermes", "skills")
    return os.path.join(home, ".gemini", "config", "skills")

def run_cmd(cmd, cwd=None):
    try:
        res = subprocess.run(cmd, cwd=cwd, shell=True, capture_output=True, text=True, check=True)
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        return f"Error: {e.stderr.strip()}"

def main():
    target_skills_dir = get_target_dir()
    cache_dir = os.path.join(os.path.expanduser("~"), ".gemini", "sources")
    os.makedirs(cache_dir, exist_ok=True)
    os.makedirs(target_skills_dir, exist_ok=True)

    print("==========================================================")
    print("   ANTIGRAVITY & HERMES SKILLS UPDATER (LAPTOP/DESKTOP)   ")
    print("==========================================================")
    print(f"Target Direktori: {target_skills_dir}")
    print(f"Cache Repositori: {cache_dir}\n")

    print("[1/3] Menarik pembaruan dari GitHub...")
    for name, url in REPOS.items():
        repo_dir = os.path.join(cache_dir, name)
        if os.path.exists(os.path.join(repo_dir, ".git")):
            out = run_cmd("git pull --rebase", cwd=repo_dir)
            print(f"  - {name}: {out.splitlines()[-1] if out else 'OK'}")
        else:
            print(f"  - Cloning {name}...")
            out = run_cmd(f"git clone --depth 1 {url} {name}", cwd=cache_dir)
            print(f"    Selesai.")

    print("\n[2/3] Menyinkronkan SKILL.md ke instalasi...")
    synced = 0
    for root, dirs, files in os.walk(cache_dir):
        dirs[:] = [d for d in dirs if d not in [".git", "node_modules", "dist", "build", "vendor", "packaging"]]
        if "SKILL.md" in files:
            skill_name = os.path.basename(root)
            if skill_name == "skills":
                continue
            src_md = os.path.join(root, "SKILL.md")
            dest_dir = os.path.join(target_skills_dir, skill_name)
            os.makedirs(dest_dir, exist_ok=True)
            dest_file = os.path.join(dest_dir, "SKILL.md")
            
            with open(src_md, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            # Ensure valid name frontmatter
            if not content.startswith(f"---\nname: {skill_name}\n") and not f"name: {skill_name}" in content:
                content = content.replace("---\n", f"---\nname: {skill_name}\n", 1)

            # Ensure workspace-clean paths
            content = content.replace("/" + "sdcard/Antigravity/<nama-proyek>/", "<workspace>/<nama-proyek>/")
            content = content.replace("/" + "sdcard/Antigravity/", "<workspace>/")
            content = content.replace("/" + "sdcard", "<workspace>")

            with open(dest_file, "w", encoding="utf-8") as f:
                f.write(content)
            synced += 1

    print(f"Sinkronisasi berhasil! {synced} skills telah diperbarui.")

    print("\n[3/3] Memperbarui index skills.json...")
    all_skills = sorted(os.listdir(target_skills_dir))
    data = {
        "version": "1.0",
        "updated_at": "laptop-updater",
        "total_skills": len(all_skills),
        "skills": all_skills
    }
    json_path = os.path.join(os.path.dirname(target_skills_dir), "skills.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    print(f"Total skills aktif terindeks: {len(all_skills)}")
    print("\n[SELESAI] Seluruh skill berhasil diperbarui di laptop Anda!")

if __name__ == "__main__":
    main()
