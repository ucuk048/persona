@echo off
echo ==========================================================
echo    HERMES AGENT SKILLS UPDATER FOR WINDOWS
echo ==========================================================
python "%~dp0update_skills.py" hermes
pause
