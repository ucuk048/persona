# Ultimate Anti-AI-Slop Suite

Synthesis of 8 official anti-AI-slop repositories (Taste Skill v2, Anti-Slop 38 Rules, anti-ai-slop general, ui-ux-kit, anti-slop-design, anti-slop Oxlint, anti-slop writing, and anti-ai-slop bilingual ID/EN).

## Skills Included
- `ultimate-anti-ai-slop`: Zero-Emoji enforcement, Brief Inference, The 3 Dials, PASS/FAIL Quality Gate.
- `anti-ai-slop-bilingual`: Bilingual English & Indonesian AI tell remover.
- `anti-ai-slop-general`: General AI pattern detector.
- `anti-slop-design`: Distinctive non-generic UI patterns.
- `anti-slop-oxlint`: ESLint/Oxlint anti-slop rules.
- `anti-slop-writing`: Human copywriting floor and de-slopping.
- `hallmark`: Anti-AI-slop design architecture and audits.
- `interface-design`: Craft-first product UI and SaaS tools.

## License
MIT
