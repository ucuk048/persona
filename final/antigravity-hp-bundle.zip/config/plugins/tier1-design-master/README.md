# Tier-1 Enterprise Design Master

Master architecture and quality gate for Tier-1 Enterprise Design Systems (6 Pilar Utama: Apple, Linear, Vercel, Supabase, Samsung, Stripe).

## Skills Included
- `tier1-design-master`: Master design system quality gate, 3-layer surface depth, restrained accent palettes.
- `apple-design`: Human Interface Guidelines (HIG) compliance and multi-platform consistency.
- `design-system`: 3-layer CSS variable tokens (primitive -> semantic -> component).
- `design`: Visual identity, corporate identity programs, asset generation.
- `brand`: Brand consistency, tone of voice, visual world decks.
- `banner-design`: Curated banner and hero art direction.
- `slides`: Data-driven HTML presentations with Chart.js.

## License
MIT
