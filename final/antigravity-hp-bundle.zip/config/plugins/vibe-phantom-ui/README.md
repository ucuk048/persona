# Vibe & Phantom UI Suite

Modern expressive UI components, tactile micro-interactions, structure-aware skeleton loading, and UI/UX design intelligence.

## Skills Included
- `phantom-ui`: Structure-aware skeleton loader Web Component for every framework.
- `ui-ux-pro-max`: UI/UX design intelligence (79 styles, 192 product palettes, 74 font pairings).
- `vibe-ui`: Ambient surface effects, glowing border cards, tactile interactions.

## License
MIT
