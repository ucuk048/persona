<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://github.com/miqdadbadjuber/anti-slop/raw/main/assets/antislop-banner.png">
    <source media="(prefers-color-scheme: light)" srcset="https://github.com/miqdadbadjuber/anti-slop/raw/main/assets/antislop-banner-light.png">
    <img src="https://github.com/miqdadbadjuber/anti-slop/raw/main/assets/antislop-banner-light.png" alt="antislop" width="100%" />
  </picture>
</p>

<div align="center">

# Anti Slop: Rules for AI Coding Agents

<code>npx antislop-ai</code>

[Website](https://antislop.ai.id) · [Guide](GUIDE.md) · [Roadmap](ROADMAP.md) · [Install](#install) · [Skills](#skills) · [FAQ](#faq)

[![npm version](https://img.shields.io/npm/v/antislop-ai?style=flat-square&color=cb3837&label=npm)](https://www.npmjs.com/package/antislop-ai)
[![Node.js](https://img.shields.io/badge/Node.js-20.12%2B-339933?style=flat-square&logo=nodedotjs&logoColor=white)](cli/package.json)
[![skills.sh](https://skills.sh/b/miqdadbadjuber/anti-slop?style=flat-square)](https://skills.sh/miqdadbadjuber/anti-slop)
[![MIT license](https://img.shields.io/badge/license-MIT-f4c430?style=flat-square)](LICENSE)
[![Discord](https://img.shields.io/badge/Discord-join-5865F2?style=flat-square&logo=discord&logoColor=white)](https://discord.gg/VWKggJfHFR)

<a href="https://trendshift.io/repositories/137042?utm_source=trendshift-badge&amp;utm_medium=badge&amp;utm_campaign=badge-trendshift-137042" target="_blank" rel="noopener noreferrer"><img src="https://trendshift.io/api/badge/trendshift/repositories/137042/daily?language=JavaScript" alt="Trendshift Daily Trending" width="250" height="55"/></a>
<a href="https://trendshift.io/repositories/137042?utm_source=trendshift-badge&amp;utm_medium=badge&amp;utm_campaign=badge-trendshift-137042" target="_blank" rel="noopener noreferrer"><img src="https://trendshift.io/api/badge/trendshift/repositories/137042/monthly?language=JavaScript" alt="Trendshift Monthly Trending" width="250" height="55"/></a>

</div>

---

**antislop** is a rulebook an AI coding agent reads every session. It stops generic UI, text, and AI-shaped code, and it is a filter, not a style guide: no colors, fonts, or layouts prescribed, direction stays yours. Inside are 40 rules in three tiers, a Liveliness Toolkit, a mandatory PASS/FAIL report, and six skills that load only when a task needs them. It cannot invent direction, so DESIGN.md supplies that, and antislop never beautifies on its own.

## Before and after

Each pair below is one brief, run twice, so the difference is visible side by side.

### UI

With /antislop-ui. antislop alone is not the after. It removes the slop and stops there; direction comes from `DESIGN.md`. For UI work you intend to ship, that file is mandatory: without it the result is labelled a draft without direction. The pair below is the result.

| **Before: without antislop** | **After: antislop + `DESIGN.md`** |
|:--|:--|
| <a href="assets/compare/ui/without.webp"><img src="assets/compare/ui/without.webp" alt="The before: a generic landing page with a sparkle logo, a NEXT-GEN AI 2.0 beta pill above the headline, and a fake terminal reporting 0.0001ms latency" width="100%"></a> | <a href="assets/compare/ui/w-all.webp"><img src="assets/compare/ui/w-all.webp" alt="The after: the same page with antislop and DESIGN.md, a full-bleed illustrated hero with one honest headline and project-specific navigation" width="100%"></a> |
| This is what most AI output looks like: slop everywhere once you take a closer look. | Much better. antislop kills the slop, and `DESIGN.md` gives it a real visual direction. |

The two partial states are worth seeing, because each one shows why the other half matters:

| **Partial: antislop alone** | **Partial: `DESIGN.md` alone** |
|:--|:--|
| <a href="assets/compare/ui/w-antislop.webp"><img src="assets/compare/ui/w-antislop.webp" alt="Partial result: antislop with no design direction, a plain dark layout with the invented numbers removed" width="100%"></a> | <a href="assets/compare/ui/w-design.webp"><img src="assets/compare/ui/w-design.webp" alt="Partial result: DESIGN.md with no filter, a photographic hero with stat cards still reading 10,000% ROI Synergy Multiplier" width="100%"></a> |
| The slop is gone, but so is the direction. That is why antislop needs a `DESIGN.md`. | The direction is there, but honestly it is still far from good: the slop still shows. |

### Copywriting

With /antislop-copywriting. One prompt, run twice.

<a href="assets/compare/copywriting/before-after.png"><img src="assets/compare/copywriting/before-after.png" alt="Side by side: before, an AI written Discord launch post with NEW DROP in capitals, emoji bullets, and hype in every line; after, the same post in plain sentences, with a note to cut any line that has nothing real to say" width="100%"></a>

### Accessibility

With /antislop-human. One sign-in form, run twice.

<a href="assets/compare/human/before-after.png"><img src="assets/compare/human/before-after.png" alt="Side by side: before, a sign-in form with pale grey labels, a radio button, and blue body links; after, the same form with darker labels, a checkbox, underlined links, and a solid black button" width="100%"></a>

### Mobile layout

With /antislop-layoutmobile. One dashboard on a phone, run twice.

<a href="assets/compare/layoutmobile/before-after.png"><img src="assets/compare/layoutmobile/before-after.png" alt="Side by side: before, a desktop finance dashboard squeezed onto a phone with a clipped headline and a wide table; after, the same screen with a donut chart, stacked allocation bars, and one readable column" width="100%"></a>

### Code

With /antislop-code. One file, run twice.

<a href="assets/compare/code/before-after.png"><img src="assets/compare/code/before-after.png" alt="Side by side: before, Python with box-drawing section banners, emoji, and a comment restating every constant; after, the same code with the banners and emoji gone and one comment left where it says something" width="100%"></a>

Every image here opens full size if you click it.

## Install

antislop ships as standard agent skills: one folder per skill, holding a `SKILL.md`. Installation differs per agent, so pick the section for the one you use. Each route is walked through from zero, with update and removal, in [GUIDE.md](GUIDE.md#install-update-and-remove).

### The installer (recommended)

One command, then answer the prompts. It asks which skills you want, where to install them (this project or everywhere), and which agents you use, then copies the folders and writes the pointer that reloads antislop every session.

```bash
npx antislop-ai
```

### The skills directory

antislop is listed on [skills.sh](https://skills.sh/miqdadbadjuber/anti-slop), the open directory for agent skills. This copies the same folders as the installer and nothing else, so antislop reloads by description alone.

```bash
npx skills add miqdadbadjuber/anti-slop
```

### Claude Code - Plugin

```text
/plugin marketplace add https://github.com/miqdadbadjuber/anti-slop
/plugin install antislop@anti-slop
```

### Antigravity - Plugin

```bash
agy plugin install https://github.com/miqdadbadjuber/anti-slop
```

### Codex - Plugin

```bash
codex plugin marketplace add miqdadbadjuber/anti-slop
codex plugin add antislop@anti-slop
```

### Cursor - Plugin

```bash
agent plugin marketplace add https://github.com/miqdadbadjuber/anti-slop
```

Then open **Customize**, find **antislop**, and select **Install**.

### Kimi Code - Plugin

```text
/plugins install https://github.com/miqdadbadjuber/anti-slop
```

### DeepSeek Harness - Plugin

Open **Plugins**, choose **Add plugin**, paste this package name, and select **Install**:

```text
antislop-ai
```

That is the desktop route. From a terminal instead, name the profile you use:

```bash
dsh plugin --profile desktop add antislop-ai
```

### Cline - Plugin

```bash
cline plugin install https://github.com/miqdadbadjuber/anti-slop.git
```

This door covers the Cline CLI. For the VS Code or JetBrains extension, use the installer.

### Muse Code - Plugin

Muse Code keeps its plugin system behind an opt-in flag, so set it first. On macOS and Linux:

```bash
export MUSE_EXPERIMENTAL_PLUGINS=1
muse plugins marketplace add anti-slop miqdadbadjuber/anti-slop
muse plugins install antislop@anti-slop
```

On Windows, set `$env:MUSE_EXPERIMENTAL_PLUGINS = "1"` in PowerShell first, then run the two `muse` lines unchanged.

Skills load without another step. Run `muse plugins approve antislop` to enable the contrast MCP server.

### Oh My Pi - Plugin

```bash
omp plugin marketplace add miqdadbadjuber/anti-slop
omp plugin install antislop@anti-slop
```

### Pi - Package

```bash
pi install git:github.com/miqdadbadjuber/anti-slop
```

### The single file

`antislop.md` on its own is a complete filter you can paste into any chat window, with no packaging and no folders.

```bash
curl -o antislop.md https://raw.githubusercontent.com/miqdadbadjuber/anti-slop/main/antislop.md
```

## Skills

| Skill | Covers | Pick it for |
|-------|--------|-------------|
| antislop | The core filter: rules, tiers, the Delivery Gate, liveliness | Everything. Always loaded |
| antislop-ui | Layout, color, components, decoration, motion, structure, performance | UI and visual work |
| antislop-copywriting | Headlines, CTAs, tone, fake stats, anti-AI writing, markdown hygiene | Copy and text |
| antislop-human | Contrast, keyboard, focus, states, interaction affordances | Accessibility |
| antislop-layoutmobile | Reflow across screen widths, breakpoints, grids, overflow, tap targets | Responsive work |
| antislop-code | AI-slop comments: which to remove, which to keep | Comment cleanup |

Install one, several, or the core alone.

## Usage modes

antislop runs one of two ways, and by default the agent asks which at the start of every session.

- **During** guides the work while it is built, and closes with the Delivery Gate report.
- **After** audits work that already exists: a numbered findings list, you approve what to fix, then a follow-up report.

To skip the question, save a preference once:

```bash
npx antislop-ai --mode during
```

Use `after` for the other mode. Everything else, from `--mode ask` to where the setting lives, is in [GUIDE.md](GUIDE.md#usage-modes).

## Update

antislop does not update itself. If you installed through the installer, one command replaces what is already there, in this project and under your home directory, and prints the release it replaced:

```bash
npx antislop-ai --update
```

A plugin keeps its own copy under the agent that installed it, so it updates through its own command, and the Pi package updates through Pi. Every route is listed in [GUIDE.md](GUIDE.md#install-update-and-remove). Skills load when a session starts, so start a new one afterwards.

## FAQ

**Is antislop a style guide?**
No, a filter. It rejects technique without purpose and requires liveliness. Direction is yours.

**Which agents does it work with?**
Claude Code, Codex, Antigravity, OpenCode, Cursor, Cline, Amp, Gemini CLI, Hermes, GitHub Copilot, Kimi Code, DeepSeek Harness, Muse Code, Kilo Code, Pi, and Oh My Pi. The installer covers fifteen of them and detects which ones you have, and the plugin doors install from this same repository. [GUIDE.md](GUIDE.md) lists the folder each agent reads.

**What is a skill?**
A folder that goes deeper into one concern, holding a `SKILL.md` with its rules. Skills reference the core rules by number and never duplicate them, so adding one does not change the core.

## Roadmap

**v3.2.30** adds Kilo Code to the installer:

- **Shared folder.** Kilo Code reads `.agents/skills` at both scopes, the folder Antigravity, Copilot, Kimi Code, Amp, DeepSeek Harness, and Muse Code already share.
- **A folder of its own.** Kilo Code also documents `.kilo/skills/`, but the shared folder is loaded by default, so the installer writes one copy.

Every earlier release, and what comes next, is in [ROADMAP.md](ROADMAP.md).

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=miqdadbadjuber/anti-slop&type=Date)](https://star-history.com/#miqdadbadjuber/anti-slop&Date)

## Contributors

Thanks to everyone who helps make antislop better.

<p align="center">
  <a href="https://github.com/miqdadbadjuber/anti-slop/graphs/contributors">
    <img src="https://contrib.rocks/image?repo=miqdadbadjuber/anti-slop&v=3.2.30" alt="antislop contributors" />
  </a>
</p>

Found a new slop pattern, a rule that missed something, or a bug in the installer? Open an [issue](https://github.com/miqdadbadjuber/anti-slop/issues). What a pull request has to carry is in [CONTRIBUTING.md](CONTRIBUTING.md), and behavior in issues and pull requests is covered by [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).

<hr>

<p align="center"><em>“antislop is a filter, not magic.<br>
It clears the slop from your UI, text, and code.<br>
A beautiful UI is <code>DESIGN.md</code>'s job, and yours.”</em></p>

<hr>

## Disclaimer

Get antislop from [miqdadbadjuber/anti-slop](https://github.com/miqdadbadjuber/anti-slop), [antislop.ai.id](https://antislop.ai.id), or the [antislop-ai npm package](https://www.npmjs.com/package/antislop-ai). The npm name `antislop` belongs to a different package, so `npx antislop` does not install this project.

There is no antislop coin, token, or fundraising. Any crypto coin, token, NFT, or fundraising that uses the antislop name was not created by this project and is a scam. antislop accepts donations only through the Sponsor button on this repository and [Saweria](https://saweria.co/antislop); anyone collecting money in its name anywhere else is not authorized.

## License

MIT: [LICENSE](LICENSE)
