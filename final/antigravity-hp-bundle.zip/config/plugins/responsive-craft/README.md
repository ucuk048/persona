# Responsive Craft & Thumb-First Suite

Comprehensive responsive design, fluid viewport budgeting, and mobile touch ergonomics for web applications.

## Skills Included
- `responsive-craft`: Fluid typography clamp(), 3-layer responsive system, 100dvh first-screen budgeting.
- `thumb-first`: Unified mobile design and technical defect auditor.
- `thumb-first-design`: Touch zones, navigation patterns, reach ergonomics.
- `thumb-first-platform`: iOS Safari / Android Chrome viewport bugs, safe area insets, touch targets 44x44px.

## License
MIT
