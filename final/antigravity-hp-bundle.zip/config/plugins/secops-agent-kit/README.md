# SecOpsAgentKit — Enterprise DevSecOps & Security Operations Suite

SecOpsAgentKit provides enterprise security operations, automated vulnerability validation, STRIDE threat modeling, static/dynamic scanning, OWASP ZAP auditing, and DevSecOps workflow automation for AI coding agents.

## Modules & Skills
- `secops-agent-kit`: STRIDE/PASTA threat modeling, SAST, secret auditing, IaC hardening.
- `owasp-zap-security`: Dynamic application security testing, HTTP headers enforcement, injection mitigation, clickjacking framebusting.

## License
Apache-2.0
