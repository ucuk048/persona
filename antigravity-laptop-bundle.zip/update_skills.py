#!/usr/bin/env python3
"""
Antigravity & Hermes Universal Skills Updater
Memperbarui seluruh skill dari repositori Git hulu, menyinkronkan ke HP, 
dan memperbarui paket bundle Laptop serta Hermes secara otomatis.
"""

import os
import subprocess
import json
import zipfile
import shutil

BASE_DIR = "/sdcard/Antigravity"
CUSTOM_SRC = os.path.join(BASE_DIR, "customizations_src")
HP_SKILLS_GLOBAL = os.path.expanduser("~/.gemini/config/skills")
HP_SKILLS_LOCAL = os.path.join(BASE_DIR, ".agents/skills")
LAPTOP_SKILLS = os.path.join(BASE_DIR, "laptop_bundle/config/skills")
HERMES_SKILLS = os.path.join(BASE_DIR, "hermes_bundle/skills")

def run_cmd(cmd, cwd=None):
    try:
        res = subprocess.run(cmd, cwd=cwd, shell=True, capture_output=True, text=True, check=True)
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        return f"Error: {e.stderr.strip()}"

def update_git_repos():
    print("=== [1/4] Memeriksa & Mengunduh Update Repositori Git ===")
    if not os.path.exists(CUSTOM_SRC):
        print("Direktori customizations_src tidak ditemukan.")
        return

    repos = [d for d in os.listdir(CUSTOM_SRC) if os.path.isdir(os.path.join(CUSTOM_SRC, d))]
    for repo in sorted(repos):
        repo_path = os.path.join(CUSTOM_SRC, repo)
        git_dir = os.path.join(repo_path, ".git")
        if os.path.exists(git_dir):
            remotes = run_cmd("git remote", cwd=repo_path)
            if not remotes or remotes.startswith("Error"):
                print(f"  - {repo}: Repositori lokal (tanpa remote upstream).")
                continue

            status = run_cmd("git status --porcelain", cwd=repo_path)
            dirty = bool(status and not status.startswith("Error") and status.strip())
            if dirty:
                run_cmd("git stash", cwd=repo_path)

            out = run_cmd("git pull --rebase", cwd=repo_path)

            if dirty:
                run_cmd("git stash pop", cwd=repo_path)

            last_line = out.splitlines()[-1] if out else "OK"
            print(f"  - {repo}: {last_line}")

def sync_skills():
    print("\n=== [2/4] Menyinkronkan Berkas Skills ke Sistem ===")
    count = 0
    for root, dirs, files in os.walk(CUSTOM_SRC):
        # Prune heavy non-skill dirs
        dirs[:] = [d for d in dirs if d not in [".git", ".claude", ".claude-plugin", ".github", "node_modules", "dist", "build", "vendor", "packaging"]]
        if "SKILL.md" in files:
            skill_name = os.path.basename(root)
            src_skill_md = os.path.join(root, "SKILL.md")
            
            with open(src_skill_md, "r", encoding="utf-8", errors="ignore") as f_in:
                raw_content = f_in.read()

            fm_name = None
            for line in raw_content.splitlines()[:25]:
                if line.startswith("name:"):
                    fm_name = line.split(":", 1)[1].strip().strip("'\"")
                    break

            if skill_name in ["skills", "skill"]:
                skill_names = [fm_name] if fm_name else []
            else:
                skill_names = [skill_name]
                if fm_name and fm_name != skill_name and fm_name not in ["skills", "skill"]:
                    skill_names.append(fm_name)
                if skill_name == "ffmpeg-skill" and "ffmpeg" not in skill_names:
                    skill_names.append("ffmpeg")
                if skill_name == "scrapling" and "scrapling-official" not in skill_names:
                    skill_names.append("scrapling-official")

            for s_name in skill_names:
                targets = [
                    os.path.join(HP_SKILLS_GLOBAL, s_name),
                    os.path.join(HP_SKILLS_LOCAL, s_name),
                    os.path.join(LAPTOP_SKILLS, s_name),
                    os.path.join(HERMES_SKILLS, s_name)
                ]
                
                for t in targets:
                    os.makedirs(t, exist_ok=True)
                    dest_file = os.path.join(t, "SKILL.md")
                    content = raw_content
                    if s_name != fm_name and fm_name:
                        content = content.replace(f"name: {fm_name}", f"name: {s_name}", 1)
                    if "laptop" in t or "hermes" in t:
                        content = content.replace("/sdcard/Antigravity/<nama-proyek>/", "<workspace>/<nama-proyek>/")
                        content = content.replace("/sdcard/Antigravity/", "<workspace>/")
                        content = content.replace("/sdcard", "<workspace>")
                    with open(dest_file, "w", encoding="utf-8") as f_out:
                        f_out.write(content)
                
                # Copy all companion files (.md, .json, .cjs, .js, .py, etc.) and subdirectories
                for item in os.listdir(root):
                    src_item = os.path.join(root, item)
                    if os.path.isfile(src_item) and item != "SKILL.md":
                        if not item.endswith((".png", ".jpg", ".jpeg", ".webp", ".zip", ".tar.gz", ".mp4", ".gif", ".mov", ".mkv", ".webm")):
                            for t in targets:
                                dst_file = os.path.join(t, item)
                                shutil.copy2(src_item, dst_file)
                    elif os.path.isdir(src_item) and item not in [".git", ".claude", ".claude-plugin", ".github", "node_modules", "__pycache__", "public", ".next", "snapshots", "dist", "build", "vendor", "packaging", "evals", "tests"]:
                        for t in targets:
                            dst_sub = os.path.join(t, item)
                            if os.path.exists(dst_sub):
                                shutil.rmtree(dst_sub)
                            shutil.copytree(src_item, dst_sub, ignore=shutil.ignore_patterns("*.png", "*.jpg", "*.jpeg", "*.webp", "*.zip", "*.tar.gz", "*.mp4", "*.gif", "*.mov", "*.mkv", "*.webm", ".git"))

            count += 1

    print(f"Sinkronisasi selesai ({count} skills dari repositori hulu terupdate).")

def update_indexes():
    print("\n=== [3/4] Memperbarui Index JSON & Status ===")
    all_skills = sorted(os.listdir(HP_SKILLS_GLOBAL))
    data = {
        "version": "1.0",
        "updated_at": "auto-updater",
        "total_skills": len(all_skills),
        "skills": all_skills
    }
    
    for json_p in [
        os.path.expanduser("~/.gemini/config/skills.json"),
        os.path.join(BASE_DIR, ".agents/skills.json"),
        os.path.join(BASE_DIR, "laptop_bundle/config/skills.json")
    ]:
        with open(json_p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            
    print(f"Total skills aktif terindeks: {len(all_skills)}")

def make_zip(src_dir, zip_path):
    if os.path.exists(zip_path):
        os.remove(zip_path)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(src_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, src_dir)
                zipf.write(full_path, rel_path)
    size_kb = os.path.getsize(zip_path) / 1024
    print(f"  - {os.path.basename(zip_path)}: {size_kb:.1f} KB")

def rebuild_bundles():
    print("\n=== [4/4] Membangun Ulang Paket Bundle Laptop & Hermes ===")
    hp_staging = os.path.join(BASE_DIR, "hp_bundle")
    hp_skills_staging = os.path.join(hp_staging, "config/skills")
    if os.path.exists(hp_skills_staging):
        shutil.rmtree(hp_skills_staging)
    shutil.copytree(HP_SKILLS_GLOBAL, hp_skills_staging, ignore=shutil.ignore_patterns("*.png", "*.jpg", "*.jpeg", "*.webp", "*.zip", "*.tar.gz", "*.mp4", "*.gif", "*.mov", "*.mkv", "*.webm", ".git"))
    shutil.copy2(os.path.expanduser("~/.gemini/config/skills.json"), os.path.join(hp_staging, "config/skills.json"))
    shutil.copy2(os.path.expanduser("~/.gemini/config/GEMINI.md"), os.path.join(hp_staging, "config/GEMINI.md"))
    shutil.copy2(os.path.join(BASE_DIR, "terpasang.txt"), os.path.join(hp_staging, "terpasang.txt"))
    
    make_zip(hp_staging, os.path.join(BASE_DIR, "antigravity-hp-bundle.zip"))
    make_zip(os.path.join(BASE_DIR, "laptop_bundle"), os.path.join(BASE_DIR, "antigravity-laptop-bundle.zip"))
    make_zip(os.path.join(BASE_DIR, "hermes_bundle"), os.path.join(BASE_DIR, "antigravity-hermes-bundle.zip"))

import sys

def main():
    print("==================================================")
    print("   UNIVERSAL SKILLS UPDATER (HP / LAPTOP / HERMES)")
    print("==================================================")
    if "--sync-only" not in sys.argv and "-s" not in sys.argv:
        update_git_repos()
    else:
        print("[INFO] Mode Sync-Only aktif: Melewati update git pull hulu.")
    sync_skills()
    update_indexes()
    rebuild_bundles()
    print("\n[SELESAI] Seluruh skill berhasil diperbarui dan disinkronkan!")

if __name__ == "__main__":
    main()
