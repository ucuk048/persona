@echo off
echo ==========================================================
echo    ANTIGRAVITY SKILLS UPDATER FOR WINDOWS
echo ==========================================================
python "%~dp0update_skills.py"
pause
