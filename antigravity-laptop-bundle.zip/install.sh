#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "   ANTIGRAVITY (AGY) CONFIGURATION INSTALLER FOR LINUX/MAC"
echo "=========================================================="

TARGET_DIR="$HOME/.gemini"
CONFIG_DIR="$TARGET_DIR/config"
CLI_DIR="$TARGET_DIR/antigravity-cli"

echo "[1/4] Membuat direktori target di $TARGET_DIR..."
mkdir -p "$CONFIG_DIR"
mkdir -p "$CLI_DIR"
mkdir -p "$CONFIG_DIR/skills"

echo "[2/4] Menyalin 633 Skills & Skills Index..."
cp -r config/skills/* "$CONFIG_DIR/skills/"
cp config/skills.json "$CONFIG_DIR/skills.json"

echo "[3/4] Memasang Rules & Personas (GEMINI.md)..."
cp config/GEMINI.md "$CONFIG_DIR/GEMINI.md"

echo "[4/4] Mengonfigurasi Settings & Always-Allow Permissions..."
if [ -f "$CLI_DIR/settings.json" ]; then
    echo "  - Backup settings.json lama ke settings.json.bak..."
    cp "$CLI_DIR/settings.json" "$CLI_DIR/settings.json.bak"
fi

# Tulis settings.json dengan trustedWorkspaces disesuaikan ke $HOME
cat <<EOF > "$CLI_DIR/settings.json"
{
  "agentMode": "accept-edits",
  "allowNonWorkspaceAccess": true,
  "artifactReviewPolicy": "always-proceed",
  "model": "Gemini 3.8 Flash (High)",
  "notifications": true,
  "permissions": {
    "allow": [
      "*",
      "command(*)",
      "read_file(*)",
      "write_file(*)",
      "edit_file(*)",
      "search_web(*)",
      "manage_task(*)",
      "manage_subagents(*)",
      "invoke_subagent(*)",
      "schedule(*)"
    ]
  },
  "runningLightSpeed": "fast",
  "toolPermission": "always-proceed",
  "trustedWorkspaces": [
    "$HOME"
  ],
  "useG1Credits": true,
  "verbosity": "high"
}
EOF

echo ""
echo "=========================================================="
echo " [SUCCESS] Seluruh 633 skills, rules & settings berhasil"
echo "           terpasang di laptop Linux/macOS Anda!"
echo " Direktori Config: $CONFIG_DIR"
echo " Direktori Settings: $CLI_DIR/settings.json"
echo "=========================================================="
